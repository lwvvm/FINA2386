"""
全球人口贩运网络数据加载和预处理模块
Global Human Trafficking Network - Data Loader and Preprocessor
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')


class TraffickingDataLoader:
    """人口贩运数据加载器"""
    
    def __init__(self, file_path: str):
        """
        初始化数据加载器
        
        Args:
            file_path: Excel文件路径
        """
        self.file_path = file_path
        self.sheets = {}
        self.edge_data = None
        self.victim_data = None
        
    def load_all_sheets(self) -> Dict[str, pd.DataFrame]:
        """加载所有sheet数据"""
        xl_file = pd.ExcelFile(self.file_path)
        
        for sheet_name in xl_file.sheet_names:
            self.sheets[sheet_name] = pd.read_excel(
                self.file_path, 
                sheet_name=sheet_name
            )
            print(f"已加载 {sheet_name}: {self.sheets[sheet_name].shape}")
        
        return self.sheets
    
    def load_edge_data(self, sheet_name: str = 'Edited edge') -> pd.DataFrame:
        """
        加载边数据（贩运流）
        
        Args:
            sheet_name: sheet名称
            
        Returns:
            边数据DataFrame
        """
        if sheet_name not in self.sheets:
            self.sheets[sheet_name] = pd.read_excel(
                self.file_path, 
                sheet_name=sheet_name
            )
        
        self.edge_data = self.sheets[sheet_name].copy()
        # 重命名列为标准名称
        self.edge_data.columns = ['source', 'target']
        
        return self.edge_data
    
    def load_victim_data(self, sheet_name: str = 'Filtered more y,cg,c,c') -> pd.DataFrame:
        """
        加载受害者数据
        
        Args:
            sheet_name: sheet名称
            
        Returns:
            受害者数据DataFrame
        """
        if sheet_name not in self.sheets:
            self.sheets[sheet_name] = pd.read_excel(
                self.file_path, 
                sheet_name=sheet_name
            )
        
        self.victim_data = self.sheets[sheet_name].copy()
        
        return self.victim_data
    
    def get_network_statistics(self) -> Dict:
        """获取网络基本统计信息"""
        if self.edge_data is None:
            self.load_edge_data()
        
        stats = {
            '总边数': len(self.edge_data),
            '来源国数量': self.edge_data['source'].nunique(),
            '目的国数量': self.edge_data['target'].nunique(),
            '总国家数': len(set(self.edge_data['source'].unique()) | 
                          set(self.edge_data['target'].unique())),
            '来源国列表': sorted(self.edge_data['source'].unique()),
            '目的国列表': sorted(self.edge_data['target'].unique()),
        }
        
        return stats
    
    def get_victim_statistics(self) -> Dict:
        """获取受害者数据统计信息"""
        if self.victim_data is None:
            self.load_victim_data()
        
        df = self.victim_data
        
        stats = {
            '总受害者数': len(df),
            '性别分布': df['gender'].value_counts().to_dict(),
            '年龄段分布': df['ageBroad'].value_counts().to_dict(),
            '年份范围': (df['yearOfRegistration'].min(), 
                      df['yearOfRegistration'].max()),
            '国籍数量': df['citizenship'].nunique(),
            '剥削国数量': df['CountryOfExploitation'].nunique(),
        }
        
        # 剥削类型统计
        exploitation_types = []
        if 'isForcedLabour' in df.columns:
            forced_labour = df['isForcedLabour'].sum()
            if pd.notna(forced_labour):
                exploitation_types.append(('强制劳动', int(forced_labour)))
        
        if 'isSexualExploit' in df.columns:
            sexual = df['isSexualExploit'].sum()
            if pd.notna(sexual):
                exploitation_types.append(('性剥削', int(sexual)))
        
        if 'isOtherExploit' in df.columns:
            other = df['isOtherExploit'].sum()
            if pd.notna(other):
                exploitation_types.append(('其他剥削', int(other)))
        
        stats['剥削类型分布'] = exploitation_types
        
        return stats


class DataPreprocessor:
    """数据预处理器"""
    
    @staticmethod
    def clean_victim_data(df: pd.DataFrame) -> pd.DataFrame:
        """
        清理受害者数据
        
        Args:
            df: 原始DataFrame
            
        Returns:
            清理后的DataFrame
        """
        df_clean = df.copy()
        
        # 移除完全重复的行
        df_clean = df_clean.drop_duplicates()
        
        # 处理年份
        if 'yearOfRegistration' in df_clean.columns:
            df_clean['yearOfRegistration'] = pd.to_numeric(
                df_clean['yearOfRegistration'], 
                errors='coerce'
            )
        
        # 处理性别
        if 'gender' in df_clean.columns:
            df_clean['gender'] = df_clean['gender'].fillna('Unknown')
        
        # 处理年龄段
        if 'ageBroad' in df_clean.columns:
            df_clean['ageBroad'] = df_clean['ageBroad'].fillna('Unknown')
        
        return df_clean
    
    @staticmethod
    def create_age_groups(df: pd.DataFrame) -> pd.DataFrame:
        """
        创建年龄组分类
        
        Args:
            df: 含有年龄数据的DataFrame
            
        Returns:
            添加年龄组列的DataFrame
        """
        df_age = df.copy()
        
        if 'ageBroad' in df_age.columns:
            # 定义18-30岁组
            def categorize_age(age_broad):
                if pd.isna(age_broad):
                    return 'Unknown'
                age_str = str(age_broad).lower()
                
                # 检查是否包含18-30岁范围
                if any(x in age_str for x in ['18', '19', '20', '21', '22', 
                                                '23', '24', '25', '26', '27', 
                                                '28', '29', '30', 'adult', 
                                                'young']):
                    return '18-30岁'
                elif 'child' in age_str or 'minor' in age_str or '17' in age_str:
                    return '未成年'
                elif '31' in age_str or '40' in age_str or '50' in age_str:
                    return '30岁以上'
                else:
                    return 'Unknown'
            
            df_age['age_group'] = df_age['ageBroad'].apply(categorize_age)
        
        return df_age
    
    @staticmethod
    def extract_exploitation_types(df: pd.DataFrame) -> pd.DataFrame:
        """
        提取剥削类型信息
        
        Args:
            df: 含有剥削类型数据的DataFrame
            
        Returns:
            添加剥削类型摘要的DataFrame
        """
        df_exploit = df.copy()
        
        # 创建剥削类型列表
        def get_exploitation_types(row):
            types = []
            if row.get('isForcedLabour', 0) == 1:
                types.append('强制劳动')
            if row.get('isSexualExploit', 0) == 1:
                types.append('性剥削')
            if row.get('isOtherExploit', 0) == 1:
                types.append('其他')
            return ', '.join(types) if types else 'Unknown'
        
        df_exploit['exploitation_types'] = df_exploit.apply(
            get_exploitation_types, 
            axis=1
        )
        
        return df_exploit
    
    @staticmethod
    def get_country_pairs(df: pd.DataFrame, 
                         source_col: str = 'citizenship',
                         target_col: str = 'CountryOfExploitation') -> pd.DataFrame:
        """
        从受害者数据创建国家对（边列表）
        
        Args:
            df: 受害者DataFrame
            source_col: 来源国列名
            target_col: 目的国列名
            
        Returns:
            国家对DataFrame
        """
        pairs = df[[source_col, target_col]].copy()
        pairs.columns = ['source', 'target']
        
        # 移除缺失值
        pairs = pairs.dropna()
        
        # 计算每对的频率
        pair_counts = pairs.groupby(['source', 'target']).size().reset_index(
            name='weight'
        )
        
        return pair_counts


if __name__ == '__main__':
    # 测试数据加载
    print("="*60)
    print("全球人口贩运网络数据分析 - 数据加载测试")
    print("="*60)
    
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    
    # 加载所有sheets
    print("\n1. 加载所有数据sheets...")
    loader.load_all_sheets()
    
    # 加载边数据
    print("\n2. 加载边数据...")
    edge_data = loader.load_edge_data()
    print(f"边数据形状: {edge_data.shape}")
    print(edge_data.head())
    
    # 获取网络统计
    print("\n3. 网络统计信息:")
    net_stats = loader.get_network_statistics()
    for key, value in net_stats.items():
        if key not in ['来源国列表', '目的国列表']:
            print(f"  {key}: {value}")
    
    # 加载受害者数据
    print("\n4. 加载受害者数据...")
    victim_data = loader.load_victim_data()
    print(f"受害者数据形状: {victim_data.shape}")
    
    # 获取受害者统计
    print("\n5. 受害者统计信息:")
    victim_stats = loader.get_victim_statistics()
    for key, value in victim_stats.items():
        print(f"  {key}: {value}")
    
    # 数据预处理测试
    print("\n6. 数据预处理...")
    preprocessor = DataPreprocessor()
    clean_data = preprocessor.clean_victim_data(victim_data)
    clean_data = preprocessor.create_age_groups(clean_data)
    clean_data = preprocessor.extract_exploitation_types(clean_data)
    
    print(f"清理后数据形状: {clean_data.shape}")
    print("\n年龄组分布:")
    print(clean_data['age_group'].value_counts())
    print("\n剥削类型分布:")
    print(clean_data['exploitation_types'].value_counts())
    
    print("\n数据加载测试完成！")

