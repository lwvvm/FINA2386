"""
Complete Advanced Analysis Runner
运行完整的高级分析 - 包含所有模型和炫酷可视化
"""

import sys
from datetime import datetime
from data_loader import TraffickingDataLoader
from network_analysis import TraffickingNetworkAnalyzer
from advanced_models import run_all_models
from advanced_visualization import create_all_fancy_visualizations


def main():
    """主函数 - 运行完整的高级分析"""
    
    print("="*80)
    print(" "*15 + "ADVANCED HUMAN TRAFFICKING NETWORK ANALYSIS")
    print(" "*20 + "高级人口贩运网络分析系统")
    print("="*80)
    print(f"\nStart Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # ========== 1. 数据加载 ==========
    print("="*80)
    print("STEP 1: DATA LOADING")
    print("="*80)
    
    data_file = 'CTDC_global_synthetic_data_v2025.xlsx'
    print(f"Loading data from: {data_file}")
    
    loader = TraffickingDataLoader(data_file)
    edge_data = loader.load_edge_data()
    victim_data = loader.load_victim_data()
    
    print(f"✓ Edge data loaded: {edge_data.shape}")
    print(f"✓ Victim data loaded: {victim_data.shape}")
    
    # ========== 2. 网络构建 ==========
    print("\n" + "="*80)
    print("STEP 2: NETWORK CONSTRUCTION")
    print("="*80)
    
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    print(f"✓ Network created with {analyzer.graph.number_of_nodes()} nodes "
          f"and {analyzer.graph.number_of_edges()} edges")
    
    # ========== 3. 运行高级模型 ==========
    print("\n" + "="*80)
    print("STEP 3: ADVANCED MACHINE LEARNING MODELS")
    print("="*80)
    print("\nThis may take several minutes...")
    
    model_results = run_all_models(edge_data, victim_data, analyzer.graph)
    
    # ========== 4. 生成炫酷可视化 ==========
    print("\n" + "="*80)
    print("STEP 4: FANCY VISUALIZATIONS")
    print("="*80)
    
    create_all_fancy_visualizations(analyzer.graph, edge_data, model_results)
    
    # ========== 5. 生成总结报告 ==========
    print("\n" + "="*80)
    print("STEP 5: GENERATING SUMMARY REPORT")
    print("="*80)
    
    generate_summary_report(model_results)
    
    print("\n" + "="*80)
    print("ANALYSIS COMPLETED SUCCESSFULLY!")
    print("="*80)
    print(f"\nEnd Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\nAll results saved to:")
    print("  - output/fancy/       (Fancy visualizations)")
    print("  - output/             (Model results and reports)")
    print("\n" + "="*80)


def generate_summary_report(model_results: dict):
    """生成模型结果总结报告"""
    
    report_lines = []
    report_lines.append("="*80)
    report_lines.append("ADVANCED ANALYSIS SUMMARY REPORT")
    report_lines.append("高级分析总结报告")
    report_lines.append("="*80)
    report_lines.append(f"\nGenerated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append("")
    
    # Model 1: Link Prediction
    if 'link_prediction' in model_results:
        report_lines.append("-"*80)
        report_lines.append("MODEL 1: LINK PREDICTION (链接预测)")
        report_lines.append("-"*80)
        lp = model_results['link_prediction']
        report_lines.append(f"Training Accuracy: {lp['train_accuracy']:.4f}")
        report_lines.append(f"Testing Accuracy:  {lp['test_accuracy']:.4f}")
        report_lines.append(f"AUC-ROC Score:     {lp['auc_roc']:.4f}")
        report_lines.append("\nTop 5 Important Features:")
        # 自动检测列名
        value_col = 'importance' if 'importance' in lp['feature_importance'].columns else 'coefficient'
        for idx, row in lp['feature_importance'].head().iterrows():
            report_lines.append(f"  {row['feature']:30s}: {row[value_col]:.4f}")
        report_lines.append("")
    
    # Model 2: Victim Classification
    if 'victim_classification' in model_results:
        report_lines.append("-"*80)
        report_lines.append("MODEL 2: VICTIM CLASSIFICATION (受害者分类)")
        report_lines.append("-"*80)
        vc = model_results['victim_classification']
        report_lines.append(f"Training Accuracy: {vc['train_accuracy']:.4f}")
        report_lines.append(f"Testing Accuracy:  {vc['test_accuracy']:.4f}")
        report_lines.append("\nTop 5 Important Features:")
        # 自动检测列名
        value_col = 'importance' if 'importance' in vc['feature_importance'].columns else 'coefficient'
        for idx, row in vc['feature_importance'].head().iterrows():
            report_lines.append(f"  {row['feature']:30s}: {row[value_col]:.4f}")
        report_lines.append("")
    
    # Model 3: Country Clustering
    if 'country_clustering' in model_results:
        report_lines.append("-"*80)
        report_lines.append("MODEL 3: COUNTRY CLUSTERING (国家聚类)")
        report_lines.append("-"*80)
        cc = model_results['country_clustering']
        n_clusters = len(cc['data']['cluster'].unique())
        report_lines.append(f"Number of Clusters: {n_clusters}")
        report_lines.append(f"PCA Explained Variance: {cc['pca_variance'].sum():.4f}")
        report_lines.append("\nCluster Sizes:")
        for cluster in sorted(cc['data']['cluster'].unique()):
            size = (cc['data']['cluster'] == cluster).sum()
            report_lines.append(f"  Cluster {cluster}: {size} countries")
        report_lines.append("")
    
    # Model 4: Risk Scoring
    if 'risk_scoring' in model_results:
        report_lines.append("-"*80)
        report_lines.append("MODEL 4: RISK SCORING (风险评分)")
        report_lines.append("-"*80)
        rs = model_results['risk_scoring']
        report_lines.append("\nTop 10 Highest Risk Countries:")
        for idx, row in rs.head(10).iterrows():
            report_lines.append(f"  {row['country']:5s}: Overall={row['overall_risk']:8.2f} "
                              f"(Source={row['source_risk']:6.0f}, "
                              f"Dest={row['destination_risk']:6.0f}, "
                              f"Transit={row['transit_risk']:6.2f})")
        report_lines.append("")
    
    # Predicted Links
    if 'predicted_links' in model_results:
        report_lines.append("-"*80)
        report_lines.append("PREDICTED NEW TRAFFICKING ROUTES (预测的新贩运路线)")
        report_lines.append("-"*80)
        pl = model_results['predicted_links']
        report_lines.append("\nTop 10 Most Likely New Routes:")
        for idx, row in pl.head(10).iterrows():
            report_lines.append(f"  {row['source']:5s} → {row['target']:5s}: "
                              f"Probability = {row['probability']:.4f}")
        report_lines.append("")
    
    report_lines.append("="*80)
    report_lines.append("END OF REPORT")
    report_lines.append("="*80)
    
    # Save report
    report_text = '\n'.join(report_lines)
    with open('output/advanced_analysis_report.txt', 'w', encoding='utf-8') as f:
        f.write(report_text)
    
    print(report_text)
    print("\n✓ Summary report saved to: output/advanced_analysis_report.txt")


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nAnalysis interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nError occurred: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

