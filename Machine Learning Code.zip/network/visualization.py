"""
Global Human Trafficking Network - Visualization Module
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from typing import Dict, List, Optional
import warnings
warnings.filterwarnings('ignore')

# Set English font
plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# Set style
sns.set_style("whitegrid")
sns.set_palette("husl")


class NetworkVisualizer:
    """Network Visualizer"""
    
    def __init__(self, output_dir: str = 'output'):
        """
        Initialize visualizer
        
        Args:
            output_dir: Output directory
        """
        self.output_dir = output_dir
        
        # Create output directory
        import os
        os.makedirs(output_dir, exist_ok=True)
    
    def plot_network_graph(self, 
                          graph: nx.Graph, 
                          title: str = "Trafficking Network",
                          node_size_attr: Optional[str] = None,
                          top_n: int = 50,
                          figsize: tuple = (16, 12)):
        """
        Plot network graph
        
        Args:
            graph: NetworkX graph object
            title: Graph title
            node_size_attr: Node size attribute
            top_n: Show top N most important nodes
            figsize: Figure size
        """
        print(f"Plotting network graph: {title}")
        
        # Select top N nodes
        if len(graph.nodes()) > top_n:
            # Select by degree
            degree_dict = dict(graph.degree(weight='weight'))
            top_nodes = sorted(degree_dict.items(), key=lambda x: x[1], reverse=True)[:top_n]
            top_node_names = [node for node, _ in top_nodes]
            subgraph = graph.subgraph(top_node_names)
        else:
            subgraph = graph
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize)
        
        # Layout
        pos = nx.spring_layout(subgraph, k=2, iterations=50, seed=42)
        
        # Node sizes
        if node_size_attr:
            node_sizes = [subgraph.nodes[node].get(node_size_attr, 1) * 100 for node in subgraph.nodes()]
        else:
            node_sizes = [subgraph.degree(node, weight='weight') * 10 for node in subgraph.nodes()]
        
        # Edge widths
        edge_widths = [subgraph[u][v].get('weight', 1) / 100 for u, v in subgraph.edges()]
        
        # Draw network
        nx.draw_networkx_nodes(
            subgraph, pos, 
            node_size=node_sizes,
            node_color='lightblue',
            alpha=0.7,
            ax=ax
        )
        
        nx.draw_networkx_edges(
            subgraph, pos,
            width=edge_widths,
            alpha=0.3,
            edge_color='gray',
            arrows=True,
            arrowsize=10,
            ax=ax
        )
        
        nx.draw_networkx_labels(
            subgraph, pos,
            font_size=8,
            font_weight='bold',
            ax=ax
        )
        
        ax.set_title(title, fontsize=16, fontweight='bold', pad=20)
        ax.axis('off')
        
        plt.tight_layout()
        
        # Save
        filename = f"{self.output_dir}/{title.replace(' ', '_').replace(':', '')}.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_centrality_rankings(self, 
                                centrality_dict: Dict[str, Dict[str, float]],
                                top_n: int = 15):
        """
        Plot centrality rankings
        
        Args:
            centrality_dict: Centrality measures dictionary
            top_n: Show top N
        """
        print("Plotting centrality rankings...")
        
        # Translate centrality measure names to English
        name_translation = {
            '入度中心性': 'In-Degree Centrality',
            '出度中心性': 'Out-Degree Centrality',
            '介数中心性': 'Betweenness Centrality',
            '特征向量中心性': 'Eigenvector Centrality',
            'PageRank': 'PageRank'
        }
        
        n_measures = len(centrality_dict)
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        axes = axes.flatten()
        
        for idx, (measure_name, scores) in enumerate(centrality_dict.items()):
            if idx >= 4:
                break
            
            # Translate measure name
            english_name = name_translation.get(measure_name, measure_name)
            
            # Sort and get top N
            sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:top_n]
            countries = [item[0] for item in sorted_scores]
            values = [item[1] for item in sorted_scores]
            
            # Plot bar chart
            ax = axes[idx]
            bars = ax.barh(range(len(countries)), values, color='steelblue', alpha=0.7)
            ax.set_yticks(range(len(countries)))
            ax.set_yticklabels(countries, fontsize=10)
            ax.set_xlabel('Score', fontsize=12)
            ax.set_title(f'{english_name} - Top {top_n}', fontsize=14, fontweight='bold')
            ax.invert_yaxis()
            
            # Add value labels
            for i, (bar, value) in enumerate(zip(bars, values)):
                ax.text(value, i, f' {value:.4f}', va='center', fontsize=8)
        
        # Remove extra subplots
        for idx in range(len(centrality_dict), 4):
            fig.delaxes(axes[idx])
        
        plt.suptitle('Network Centrality Analysis', fontsize=18, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        filename = f"{self.output_dir}/centrality_rankings.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_victim_demographics(self, victim_data: pd.DataFrame):
        """
        Plot victim demographics
        
        Args:
            victim_data: Victim data
        """
        print("Plotting victim demographics...")
        
        fig, axes = plt.subplots(2, 2, figsize=(16, 10))
        
        # 1. Gender distribution
        if 'gender' in victim_data.columns:
            gender_counts = victim_data['gender'].value_counts()
            axes[0, 0].pie(
                gender_counts.values, 
                labels=gender_counts.index,
                autopct='%1.1f%%',
                startangle=90,
                colors=sns.color_palette('pastel')
            )
            axes[0, 0].set_title('Gender Distribution', fontsize=14, fontweight='bold')
        
        # 2. Age distribution
        if 'ageBroad' in victim_data.columns:
            age_counts = victim_data['ageBroad'].value_counts().head(10)
            axes[0, 1].bar(range(len(age_counts)), age_counts.values, color='coral', alpha=0.7)
            axes[0, 1].set_xticks(range(len(age_counts)))
            axes[0, 1].set_xticklabels(age_counts.index, rotation=45, ha='right', fontsize=9)
            axes[0, 1].set_ylabel('Number of Victims', fontsize=12)
            axes[0, 1].set_title('Age Distribution', fontsize=14, fontweight='bold')
        
        # 3. Exploitation type distribution
        exploitation_types = []
        if 'isForcedLabour' in victim_data.columns:
            exploitation_types.append(('Forced Labour', victim_data['isForcedLabour'].sum()))
        if 'isSexualExploit' in victim_data.columns:
            exploitation_types.append(('Sexual Exploitation', victim_data['isSexualExploit'].sum()))
        if 'isOtherExploit' in victim_data.columns:
            exploitation_types.append(('Other Exploitation', victim_data['isOtherExploit'].sum()))
        
        if exploitation_types:
            types, counts = zip(*exploitation_types)
            axes[1, 0].bar(types, counts, color='lightgreen', alpha=0.7)
            axes[1, 0].set_ylabel('Number of Victims', fontsize=12)
            axes[1, 0].set_title('Exploitation Type Distribution', fontsize=14, fontweight='bold')
            axes[1, 0].tick_params(axis='x', rotation=45)
            
            # Add value labels
            for i, count in enumerate(counts):
                axes[1, 0].text(i, count, f'{int(count)}', ha='center', va='bottom', fontsize=10)
        
        # 4. Top 10 source countries
        if 'citizenship' in victim_data.columns:
            top_source = victim_data['citizenship'].value_counts().head(10)
            axes[1, 1].barh(range(len(top_source)), top_source.values, color='skyblue', alpha=0.7)
            axes[1, 1].set_yticks(range(len(top_source)))
            axes[1, 1].set_yticklabels(top_source.index, fontsize=10)
            axes[1, 1].set_xlabel('Number of Victims', fontsize=12)
            axes[1, 1].set_title('Top 10 Source Countries', fontsize=14, fontweight='bold')
            axes[1, 1].invert_yaxis()
        
        plt.suptitle('Victim Demographics Analysis', fontsize=18, fontweight='bold', y=1.00)
        plt.tight_layout()
        
        filename = f"{self.output_dir}/victim_demographics.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_trafficking_routes(self, edge_data: pd.DataFrame, top_n: int = 20):
        """
        Plot major trafficking routes
        
        Args:
            edge_data: Edge data
            top_n: Show top N routes
        """
        print("Plotting major trafficking routes...")
        
        # Calculate route frequency
        route_counts = edge_data.groupby(['source', 'target']).size().reset_index(name='count')
        route_counts = route_counts.sort_values('count', ascending=False).head(top_n)
        route_counts['route'] = route_counts['source'] + ' → ' + route_counts['target']
        
        # Plot
        fig, ax = plt.subplots(figsize=(14, 10))
        
        bars = ax.barh(
            range(len(route_counts)), 
            route_counts['count'].values,
            color='steelblue',
            alpha=0.7
        )
        
        ax.set_yticks(range(len(route_counts)))
        ax.set_yticklabels(route_counts['route'].values, fontsize=10)
        ax.set_xlabel('Number of Trafficking Cases', fontsize=12)
        ax.set_title(f'Top {top_n} Major Trafficking Routes', fontsize=16, fontweight='bold')
        ax.invert_yaxis()
        
        # Add value labels
        for i, (bar, count) in enumerate(zip(bars, route_counts['count'].values)):
            ax.text(count, i, f' {int(count)}', va='center', fontsize=9)
        
        plt.tight_layout()
        
        filename = f"{self.output_dir}/trafficking_routes.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_continent_analysis(self, continent_stats: Dict):
        """
        Plot continent analysis
        
        Args:
            continent_stats: Continent statistics
        """
        print("Plotting continent analysis...")
        
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        
        # 1. Within-continent vs Cross-continent
        categories = ['Within-Continent', 'Cross-Continent']
        values = [
            continent_stats['大陆内部贩运'],
            continent_stats['跨大陆贩运']
        ]
        colors = ['lightgreen', 'lightcoral']
        
        axes[0].pie(
            values,
            labels=categories,
            autopct='%1.1f%%',
            startangle=90,
            colors=colors,
            textprops={'fontsize': 12}
        )
        axes[0].set_title('Within-Continent vs Cross-Continent Trafficking', fontsize=14, fontweight='bold')
        
        # 2. Within-continent trafficking by continent
        if '各大陆内部贩运数量' in continent_stats:
            continent_data = continent_stats['各大陆内部贩运数量']
            # Filter out Unknown
            continent_data = {k: v for k, v in continent_data.items() if k != 'Unknown'}
            
            if continent_data:
                continents = list(continent_data.keys())
                counts = list(continent_data.values())
                
                bars = axes[1].bar(
                    range(len(continents)),
                    counts,
                    color='steelblue',
                    alpha=0.7
                )
                axes[1].set_xticks(range(len(continents)))
                axes[1].set_xticklabels(continents, rotation=45, ha='right', fontsize=10)
                axes[1].set_ylabel('Number of Cases', fontsize=12)
                axes[1].set_title('Within-Continent Trafficking by Continent', fontsize=14, fontweight='bold')
                
                # Add value labels
                for i, (bar, count) in enumerate(zip(bars, counts)):
                    axes[1].text(i, count, f'{int(count)}', ha='center', va='bottom', fontsize=10)
        
        plt.suptitle('Geographic Distribution Analysis', fontsize=18, fontweight='bold', y=1.02)
        plt.tight_layout()
        
        filename = f"{self.output_dir}/continent_analysis.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_hypothesis_results(self, hypothesis_results: Dict):
        """
        Plot hypothesis testing results summary
        
        Args:
            hypothesis_results: Hypothesis testing results
        """
        print("Plotting hypothesis testing results...")
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # Extract hypotheses and support levels
        hypotheses = []
        support_levels = []
        colors_map = {
            '强支持': 'green',
            '中等支持': 'orange',
            '弱支持': 'red',
            '不支持': 'darkred',
            '无法确定': 'gray'
        }
        
        # English support level labels
        support_translation = {
            '强支持': 'Strong Support',
            '中等支持': 'Moderate Support',
            '弱支持': 'Weak Support',
            '不支持': 'Not Supported',
            '无法确定': 'Undetermined'
        }
        
        for i in range(1, 4):
            hyp_key = f'假设{i}'
            if hyp_key in hypothesis_results:
                hypotheses.append(f"Hypothesis {i}")
                support_levels.append(hypothesis_results[hyp_key]['假设支持度'])
        
        # Map support level to values
        support_to_value = {
            '强支持': 3,
            '中等支持': 2,
            '弱支持': 1,
            '不支持': 0,
            '无法确定': 0
        }
        
        values = [support_to_value[level] for level in support_levels]
        colors = [colors_map[level] for level in support_levels]
        english_levels = [support_translation[level] for level in support_levels]
        
        # Plot bar chart
        bars = ax.barh(hypotheses, values, color=colors, alpha=0.7)
        
        ax.set_xlabel('Support Level', fontsize=12)
        ax.set_xlim(0, 3.5)
        ax.set_xticks([0, 1, 2, 3])
        ax.set_xticklabels(['Not Supported', 'Weak', 'Moderate', 'Strong'], fontsize=11)
        ax.set_title('Hypothesis Testing Results Summary', fontsize=16, fontweight='bold')
        
        # Add labels
        for i, (bar, level, value) in enumerate(zip(bars, english_levels, values)):
            ax.text(value + 0.1, i, level, va='center', fontsize=11, fontweight='bold')
        
        # Add hypothesis text (in English)
        y_pos = -0.15
        hyp_texts_english = [
            "H1: Countries with same exploitation types have similar geographic/economic conditions",
            "H2: Young adults aged 18-30 are more vulnerable, with women at highest risk",
            "H3: Trafficking routes tend to be shorter distances (within same continent)"
        ]
        
        for i, hyp_text in enumerate(hyp_texts_english):
            ax.text(
                0, y_pos - i * 0.35, 
                f"Hypothesis {i+1}: {hyp_text}",
                fontsize=9,
                transform=ax.transAxes,
                wrap=True
            )
        
        plt.tight_layout()
        
        filename = f"{self.output_dir}/hypothesis_results.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()
    
    def plot_year_trend(self, victim_data: pd.DataFrame):
        """
        Plot year trend
        
        Args:
            victim_data: Victim data
        """
        if 'yearOfRegistration' not in victim_data.columns:
            return
        
        print("Plotting year trend...")
        
        # Statistics by year
        year_counts = victim_data['yearOfRegistration'].value_counts().sort_index()
        
        fig, ax = plt.subplots(figsize=(14, 6))
        
        ax.plot(year_counts.index, year_counts.values, marker='o', linewidth=2, markersize=8, color='steelblue')
        ax.fill_between(year_counts.index, year_counts.values, alpha=0.3, color='steelblue')
        
        ax.set_xlabel('Year', fontsize=12)
        ax.set_ylabel('Number of Recorded Victims', fontsize=12)
        ax.set_title('Annual Trend of Trafficking Victim Records', fontsize=16, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # Add value labels
        for year, count in zip(year_counts.index, year_counts.values):
            if not pd.isna(year):
                ax.text(year, count, f'{int(count)}', ha='center', va='bottom', fontsize=8)
        
        plt.tight_layout()
        
        filename = f"{self.output_dir}/year_trend.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        
        plt.close()


if __name__ == '__main__':
    print("="*60)
    print("Global Human Trafficking Network - Visualization Test")
    print("="*60)
    
    # Import necessary modules
    from data_loader import TraffickingDataLoader
    from network_analysis import TraffickingNetworkAnalyzer, ContinentAnalyzer
    
    # Load data
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    edge_data = loader.load_edge_data()
    victim_data = loader.load_victim_data()
    
    # Create network analyzer
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    
    # Create visualizer
    viz = NetworkVisualizer(output_dir='output')
    
    # 1. Network graph
    print("\n1. Generating network graph...")
    viz.plot_network_graph(analyzer.graph, title="Global Human Trafficking Network (Top 50 Key Countries)", top_n=50)
    
    # 2. Centrality rankings
    print("\n2. Generating centrality rankings...")
    centrality = analyzer.calculate_centrality()
    viz.plot_centrality_rankings(centrality, top_n=15)
    
    # 3. Victim demographics
    print("\n3. Generating victim demographics...")
    viz.plot_victim_demographics(victim_data)
    
    # 4. Trafficking routes
    print("\n4. Generating trafficking routes...")
    viz.plot_trafficking_routes(edge_data, top_n=20)
    
    # 5. Continent analysis
    print("\n5. Generating continent analysis...")
    continent_stats = ContinentAnalyzer.analyze_cross_continent_trafficking(edge_data.copy())
    viz.plot_continent_analysis(continent_stats)
    
    # 6. Year trend
    print("\n6. Generating year trend...")
    viz.plot_year_trend(victim_data)
    
    print("\nAll visualizations generated!")
