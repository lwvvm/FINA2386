"""
Global Human Trafficking Network - Advanced Visualization Module
高级可视化模块 - Fancy可视化效果
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx
from typing import Dict, List, Optional
import warnings
warnings.filterwarnings('ignore')

from sklearn.metrics import roc_curve, auc, confusion_matrix
from matplotlib.patches import FancyBboxPatch, Circle
import matplotlib.patches as mpatches

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")


class FancyVisualizer:
    """高级可视化器 - Fancy Visualizations"""
    
    def __init__(self, output_dir: str = 'output/fancy'):
        self.output_dir = output_dir
        import os
        os.makedirs(output_dir, exist_ok=True)
    
    def plot_circular_network(self, graph: nx.DiGraph, top_n: int = 25):
        """
        改进的环形网络图 - 更清晰的布局
        Improved circular network with better readability
        """
        print("Creating improved circular network visualization...")
        
        # Select top nodes by degree
        degree_dict = dict(graph.degree(weight='weight'))
        top_nodes = sorted(degree_dict.items(), key=lambda x: x[1], reverse=True)[:top_n]
        top_node_names = [node for node, _ in top_nodes]
        subgraph = graph.subgraph(top_node_names)
        
        fig, ax = plt.subplots(figsize=(16, 16), facecolor='white')
        ax.set_facecolor('white')
        
        # Circular layout
        pos = nx.circular_layout(subgraph)
        
        # Classify nodes by role (more precisely)
        node_data = {}
        for node in subgraph.nodes():
            in_deg = subgraph.in_degree(node, weight='weight')
            out_deg = subgraph.out_degree(node, weight='weight')
            total = in_deg + out_deg
            
            if total == 0:
                role = 'isolated'
            elif in_deg > out_deg * 2:
                role = 'destination'
            elif out_deg > in_deg * 2:
                role = 'source'
            else:
                role = 'transit'
            
            node_data[node] = {
                'role': role,
                'size': total,
                'in_deg': in_deg,
                'out_deg': out_deg
            }
        
        # Color mapping - more professional colors
        color_map = {
            'destination': '#e74c3c',  # Red
            'source': '#3498db',       # Blue
            'transit': '#f39c12',      # Orange
            'isolated': '#95a5a6'      # Gray
        }
        
        # Draw edges first (so they appear behind nodes)
        edge_weights = [d['weight'] for u, v, d in subgraph.edges(data=True)]
        max_weight = max(edge_weights) if edge_weights else 1
        
        for u, v, data in subgraph.edges(data=True):
            weight = data.get('weight', 1)
            alpha = 0.1 + 0.4 * (weight / max_weight)  # Scale alpha
            width = 0.3 + 2 * (weight / max_weight)    # Scale width
            
            ax.annotate('',
                       xy=pos[v], xycoords='data',
                       xytext=pos[u], textcoords='data',
                       arrowprops=dict(arrowstyle='->', 
                                     color='gray',
                                     alpha=alpha,
                                     lw=width,
                                     connectionstyle='arc3,rad=0.1'))
        
        # Draw nodes
        for node in subgraph.nodes():
            x, y = pos[node]
            role = node_data[node]['role']
            size = node_data[node]['size']
            
            # Scale node size
            node_size = 200 + (size / max(d['size'] for d in node_data.values())) * 1000
            
            circle = plt.Circle((x, y), radius=0.06, 
                              color=color_map[role], 
                              alpha=0.8,
                              edgecolor='black',
                              linewidth=2.5)
            ax.add_patch(circle)
            
            # Add label outside the circle
            label_distance = 0.12
            label_x = x + label_distance * np.sign(x) if abs(x) > 0.01 else x
            label_y = y + label_distance * np.sign(y) if abs(y) > 0.01 else y + label_distance
            
            ax.text(label_x, label_y, node,
                   fontsize=10,
                   fontweight='bold',
                   ha='center',
                   va='center',
                   bbox=dict(boxstyle='round,pad=0.4',
                           facecolor='white',
                           edgecolor=color_map[role],
                           linewidth=2,
                           alpha=0.9))
        
        # Enhanced legend
        legend_elements = [
            mpatches.Patch(facecolor='#e74c3c', edgecolor='black', 
                          label='Destination (High In-degree)', linewidth=2),
            mpatches.Patch(facecolor='#3498db', edgecolor='black',
                          label='Source (High Out-degree)', linewidth=2),
            mpatches.Patch(facecolor='#f39c12', edgecolor='black',
                          label='Transit (Balanced)', linewidth=2)
        ]
        ax.legend(handles=legend_elements, loc='upper right',
                 fontsize=12, framealpha=0.95, edgecolor='black', 
                 fancybox=True, shadow=True)
        
        ax.set_title('Global Human Trafficking Network\nTop 25 Countries by Trafficking Volume',
                    fontsize=18, fontweight='bold', pad=20)
        ax.set_xlim(-1.4, 1.4)
        ax.set_ylim(-1.4, 1.4)
        ax.axis('off')
        
        plt.tight_layout()
        filename = f"{self.output_dir}/circular_network_improved.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_geographic_flow_map(self, edge_data: pd.DataFrame, top_n: int = 20):
        """
        地理流向图 - 展示主要贩运路线
        Geographic flow map showing major trafficking routes
        """
        print("Creating geographic flow map...")
        
        # Get top routes
        route_counts = edge_data.groupby(['source', 'target']).size().reset_index(name='count')
        route_counts = route_counts.sort_values('count', ascending=False).head(top_n)
        
        fig, ax = plt.subplots(figsize=(16, 10))
        
        # Get unique countries
        all_countries = list(set(route_counts['source'].tolist() + route_counts['target'].tolist()))
        
        # Assign positions (simplified geographic-like layout)
        pos = {}
        angles = np.linspace(0, 2*np.pi, len(all_countries), endpoint=False)
        for i, country in enumerate(all_countries):
            pos[country] = (np.cos(angles[i]) * 5, np.sin(angles[i]) * 5)
        
        # Calculate node sizes based on total trafficking
        node_traffic = {}
        for country in all_countries:
            outgoing = route_counts[route_counts['source'] == country]['count'].sum()
            incoming = route_counts[route_counts['target'] == country]['count'].sum()
            node_traffic[country] = outgoing + incoming
        
        max_traffic = max(node_traffic.values())
        
        # Draw routes as curved arrows
        for idx, row in route_counts.iterrows():
            src = row['source']
            tgt = row['target']
            count = row['count']
            
            if src not in pos or tgt not in pos:
                continue
            
            x1, y1 = pos[src]
            x2, y2 = pos[tgt]
            
            # Line width and color intensity based on count
            width = 0.5 + 5 * (count / route_counts['count'].max())
            alpha = 0.3 + 0.6 * (count / route_counts['count'].max())
            color = plt.cm.Reds(0.3 + 0.6 * (count / route_counts['count'].max()))
            
            ax.annotate('',
                       xy=(x2, y2), xycoords='data',
                       xytext=(x1, y1), textcoords='data',
                       arrowprops=dict(
                           arrowstyle='->',
                           color=color,
                           lw=width,
                           alpha=alpha,
                           connectionstyle='arc3,rad=0.3'
                       ))
        
        # Draw nodes
        for country in all_countries:
            x, y = pos[country]
            size = 300 + 2000 * (node_traffic[country] / max_traffic)
            
            circle = plt.Circle((x, y), radius=0.3 + 0.5 * (node_traffic[country] / max_traffic),
                              color='steelblue',
                              alpha=0.7,
                              edgecolor='darkblue',
                              linewidth=2.5)
            ax.add_patch(circle)
            
            # Label
            ax.text(x, y, country,
                   fontsize=11,
                   fontweight='bold',
                   ha='center',
                   va='center',
                   color='white')
        
        ax.set_xlim(-7, 7)
        ax.set_ylim(-7, 7)
        ax.set_aspect('equal')
        ax.axis('off')
        
        ax.set_title(f'Major Trafficking Routes - Top {top_n} Routes\nArrow width indicates trafficking volume',
                    fontsize=16, fontweight='bold', pad=20)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/geographic_flow_map.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_hierarchical_network(self, graph: nx.DiGraph, top_n: int = 30):
        """
        改进的三层网络图 - 清晰展示层级结构
        Improved 3-layer network showing clear hierarchy
        """
        print("Creating improved hierarchical network...")
        
        # Select top nodes
        degree_dict = dict(graph.degree(weight='weight'))
        top_nodes = sorted(degree_dict.items(), key=lambda x: x[1], reverse=True)[:top_n]
        top_node_names = [node for node, _ in top_nodes]
        subgraph = graph.subgraph(top_node_names)
        
        fig, ax = plt.subplots(figsize=(20, 12))
        
        # Classify nodes into 3 clear layers
        layers = {'source': [], 'transit': [], 'destination': []}
        
        for node in subgraph.nodes():
            in_deg = subgraph.in_degree(node, weight='weight')
            out_deg = subgraph.out_degree(node, weight='weight')
            total = in_deg + out_deg
            
            if total == 0:
                continue
            
            ratio = in_deg / (in_deg + out_deg)
            
            if ratio > 0.7:  # Primarily destination
                layers['destination'].append((node, total))
            elif ratio < 0.3:  # Primarily source
                layers['source'].append((node, total))
            else:  # Transit/mixed
                layers['transit'].append((node, total))
        
        # Sort by traffic within each layer
        for key in layers:
            layers[key].sort(key=lambda x: x[1], reverse=True)
        
        # Create positions
        pos = {}
        y_positions = {'source': 0, 'transit': 5, 'destination': 10}
        colors_map = {
            'source': '#3498db',
            'transit': '#f39c12', 
            'destination': '#e74c3c'
        }
        
        for layer_name, nodes in layers.items():
            y = y_positions[layer_name]
            n_nodes = len(nodes)
            if n_nodes == 0:
                continue
            
            x_positions = np.linspace(-8, 8, n_nodes)
            for i, (node, traffic) in enumerate(nodes):
                pos[node] = (x_positions[i], y + np.random.randn() * 0.3)
        
        # Draw edges
        for u, v in subgraph.edges():
            if u not in pos or v not in pos:
                continue
            
            x1, y1 = pos[u]
            x2, y2 = pos[v]
            
            ax.annotate('',
                       xy=(x2, y2), xycoords='data',
                       xytext=(x1, y1), textcoords='data',
                       arrowprops=dict(
                           arrowstyle='->',
                           color='gray',
                           lw=1,
                           alpha=0.3,
                           connectionstyle='arc3,rad=0.1'
                       ))
        
        # Draw nodes
        for layer_name, nodes in layers.items():
            color = colors_map[layer_name]
            for node, traffic in nodes:
                if node not in pos:
                    continue
                
                x, y = pos[node]
                size = 0.3 + 0.5 * (traffic / max([t for _, t in nodes]))
                
                circle = plt.Circle((x, y), radius=size,
                                  color=color,
                                  alpha=0.7,
                                  edgecolor='black',
                                  linewidth=2.5)
                ax.add_patch(circle)
                
                # Label
                ax.text(x, y, node,
                       fontsize=9,
                       fontweight='bold',
                       ha='center',
                       va='center',
                       color='white' if size > 0.4 else 'black')
        
        # Layer labels
        ax.text(-10, 0, 'SOURCE\nCOUNTRIES', 
               fontsize=14, fontweight='bold',
               ha='right', va='center',
               bbox=dict(boxstyle='round,pad=0.5', facecolor='#3498db', alpha=0.7))
        
        ax.text(-10, 5, 'TRANSIT\nCOUNTRIES',
               fontsize=14, fontweight='bold',
               ha='right', va='center',
               bbox=dict(boxstyle='round,pad=0.5', facecolor='#f39c12', alpha=0.7))
        
        ax.text(-10, 10, 'DESTINATION\nCOUNTRIES',
               fontsize=14, fontweight='bold',
               ha='right', va='center',
               bbox=dict(boxstyle='round,pad=0.5', facecolor='#e74c3c', alpha=0.7))
        
        ax.set_xlim(-12, 10)
        ax.set_ylim(-2, 12)
        ax.set_aspect('equal')
        ax.axis('off')
        
        ax.set_title('Trafficking Network Hierarchy\nSource → Transit → Destination',
                    fontsize=18, fontweight='bold', pad=20)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/hierarchical_network_improved.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_flow_sankey(self, edge_data: pd.DataFrame, top_n: int = 12):
        """
        改进的流向图 - 清晰展示主要贩运路线
        Improved flow diagram showing major trafficking routes
        """
        print("Creating improved flow diagram...")
        
        # Get top routes
        route_counts = edge_data.groupby(['source', 'target']).size().reset_index(name='count')
        route_counts = route_counts.sort_values('count', ascending=False).head(top_n)
        
        fig, ax = plt.subplots(figsize=(14, 10))
        
        # Get unique sources and targets
        sources = route_counts['source'].unique()[:8]  # Limit for clarity
        targets = route_counts['target'].unique()[:8]
        
        # Filter routes to only include these
        route_counts_filtered = route_counts[
            route_counts['source'].isin(sources) & 
            route_counts['target'].isin(targets)
        ]
        
        # Create positions with better spacing
        y_spacing_src = 10 / max(len(sources), 1)
        y_spacing_tgt = 10 / max(len(targets), 1)
        
        source_pos = {src: (0, i * y_spacing_src + 1) for i, src in enumerate(sources)}
        target_pos = {tgt: (10, i * y_spacing_tgt + 1) for i, tgt in enumerate(targets)}
        
        # Calculate node sizes based on traffic
        source_traffic = route_counts_filtered.groupby('source')['count'].sum()
        target_traffic = route_counts_filtered.groupby('target')['count'].sum()
        
        max_count = route_counts_filtered['count'].max()
        
        # Draw flows with better curves
        for idx, row in route_counts_filtered.iterrows():
            src = row['source']
            tgt = row['target']
            count = row['count']
            
            if src not in source_pos or tgt not in target_pos:
                continue
            
            x1, y1 = source_pos[src]
            x2, y2 = target_pos[tgt]
            
            # Calculate flow width
            width = 0.1 + 0.6 * (count / max_count)
            
            # Create bezier curve
            t = np.linspace(0, 1, 100)
            # Control points for smooth curve
            cx1, cy1 = x1 + 3, y1
            cx2, cy2 = x2 - 3, y2
            
            # Bezier curve
            x = (1-t)**3 * x1 + 3*(1-t)**2*t * cx1 + 3*(1-t)*t**2 * cx2 + t**3 * x2
            y = (1-t)**3 * y1 + 3*(1-t)**2*t * cy1 + 3*(1-t)*t**2 * cy2 + t**3 * y2
            
            # Color gradient
            color = plt.cm.RdYlBu_r(count / max_count)
            
            ax.fill_between(x, y - width/2, y + width/2,
                          alpha=0.5, color=color, edgecolor='none')
        
        # Draw source nodes
        for src in sources:
            if src not in source_pos:
                continue
            x, y = source_pos[src]
            traffic = source_traffic.get(src, 0)
            height = 0.3 + 0.5 * (traffic / source_traffic.max() if len(source_traffic) > 0 else 0)
            
            rect = FancyBboxPatch((x-0.8, y-height/2), 1.5, height,
                                 boxstyle="round,pad=0.1",
                                 facecolor='#3498db',
                                 edgecolor='black',
                                 linewidth=2.5,
                                 alpha=0.8)
            ax.add_patch(rect)
            ax.text(x-0.05, y, src,
                   ha='center', va='center',
                   fontsize=11, fontweight='bold',
                   color='white')
        
        # Draw target nodes
        for tgt in targets:
            if tgt not in target_pos:
                continue
            x, y = target_pos[tgt]
            traffic = target_traffic.get(tgt, 0)
            height = 0.3 + 0.5 * (traffic / target_traffic.max() if len(target_traffic) > 0 else 0)
            
            rect = FancyBboxPatch((x-0.7, y-height/2), 1.5, height,
                                 boxstyle="round,pad=0.1",
                                 facecolor='#e74c3c',
                                 edgecolor='black',
                                 linewidth=2.5,
                                 alpha=0.8)
            ax.add_patch(rect)
            ax.text(x+0.05, y, tgt,
                   ha='center', va='center',
                   fontsize=11, fontweight='bold',
                   color='white')
        
        # Add labels
        ax.text(-1.5, 11, 'SOURCE\nCOUNTRIES',
               fontsize=15, fontweight='bold',
               ha='center', va='center',
               bbox=dict(boxstyle='round,pad=0.6',
                        facecolor='#3498db',
                        edgecolor='black',
                        linewidth=2,
                        alpha=0.8))
        
        ax.text(11.5, 11, 'DESTINATION\nCOUNTRIES',
               fontsize=15, fontweight='bold',
               ha='center', va='center',
               bbox=dict(boxstyle='round,pad=0.6',
                        facecolor='#e74c3c',
                        edgecolor='black',
                        linewidth=2,
                        alpha=0.8))
        
        ax.set_xlim(-3, 13)
        ax.set_ylim(0, 12)
        ax.axis('off')
        
        ax.set_title('Major Trafficking Routes - Flow Diagram\nFlow width indicates trafficking volume',
                    fontsize=16, fontweight='bold', pad=15)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/flow_diagram_improved.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_roc_curves(self, model_results: Dict):
        """
        ROC曲线 - 模型性能可视化
        ROC curves for model performance
        """
        print("Creating ROC curve visualization...")
        
        if 'X_test' not in model_results or 'y_test' not in model_results:
            print("  Skipping: No test data available")
            return
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Plot ROC curve
        y_test = model_results['y_test']
        y_prob = model_results['y_prob']
        
        fpr, tpr, _ = roc_curve(y_test, y_prob)
        roc_auc = auc(fpr, tpr)
        
        # Plot diagonal line
        ax.plot([0, 1], [0, 1], 'k--', lw=2, label='Random Classifier')
        
        # Plot ROC curve with gradient fill
        ax.plot(fpr, tpr, color='darkorange', lw=3, 
               label=f'Link Prediction Model (AUC = {roc_auc:.3f})')
        ax.fill_between(fpr, tpr, alpha=0.3, color='orange')
        
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('False Positive Rate', fontsize=13, fontweight='bold')
        ax.set_ylabel('True Positive Rate', fontsize=13, fontweight='bold')
        ax.set_title('ROC Curve - Link Prediction Model', 
                    fontsize=16, fontweight='bold', pad=15)
        ax.legend(loc="lower right", fontsize=12, framealpha=0.9)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/roc_curve.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_feature_importance(self, feature_importance: pd.DataFrame, top_n: int = 15):
        """
        特征重要性可视化
        Feature importance visualization
        """
        print("Creating feature importance visualization...")
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # 自动检测列名（支持 'importance' 或 'coefficient'）
        value_col = 'importance' if 'importance' in feature_importance.columns else 'coefficient'
        
        # 对系数取绝对值并排序
        if value_col == 'coefficient':
            feature_importance = feature_importance.copy()
            feature_importance['abs_value'] = feature_importance[value_col].abs()
            feature_importance = feature_importance.sort_values('abs_value', ascending=False)
            value_col_to_plot = value_col  # 显示原始系数（带符号）
        else:
            feature_importance['abs_value'] = feature_importance[value_col]
            value_col_to_plot = value_col
        
        top_features = feature_importance.head(top_n)
        
        # Create gradient colors
        colors = plt.cm.viridis(np.linspace(0.3, 0.9, len(top_features)))
        
        bars = ax.barh(range(len(top_features)), top_features[value_col_to_plot].values,
                      color=colors, alpha=0.8, edgecolor='black', linewidth=1.5)
        
        ax.set_yticks(range(len(top_features)))
        ax.set_yticklabels(top_features['feature'].values, fontsize=11)
        
        # 根据列名调整标签
        if value_col == 'coefficient':
            ax.set_xlabel('Coefficient Value', fontsize=13, fontweight='bold')
            ax.set_title(f'Top {top_n} Most Important Features (by Coefficient)', 
                        fontsize=16, fontweight='bold', pad=15)
        else:
            ax.set_xlabel('Importance Score', fontsize=13, fontweight='bold')
            ax.set_title(f'Top {top_n} Most Important Features for Link Prediction', 
                        fontsize=16, fontweight='bold', pad=15)
        
        ax.invert_yaxis()
        
        # Add value labels
        for i, (bar, value) in enumerate(zip(bars, top_features[value_col_to_plot].values)):
            ax.text(value, i, f' {value:.4f}', va='center', fontsize=10, fontweight='bold')
        
        ax.grid(axis='x', alpha=0.3)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/feature_importance.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_confusion_matrix_fancy(self, cm: np.ndarray, labels: List[str]):
        """
        炫酷的混淆矩阵
        Fancy confusion matrix visualization
        """
        print("Creating confusion matrix visualization...")
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Normalize
        cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        
        # Plot heatmap
        im = ax.imshow(cm_normalized, interpolation='nearest', cmap='YlOrRd')
        ax.figure.colorbar(im, ax=ax)
        
        # Set ticks
        ax.set(xticks=np.arange(cm.shape[1]),
               yticks=np.arange(cm.shape[0]),
               xticklabels=labels,
               yticklabels=labels,
               ylabel='True Label',
               xlabel='Predicted Label')
        
        # Rotate tick labels
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
        
        # Add text annotations
        thresh = cm_normalized.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, f'{cm[i, j]}\n({cm_normalized[i, j]:.2%})',
                       ha="center", va="center",
                       color="white" if cm_normalized[i, j] > thresh else "black",
                       fontsize=11, fontweight='bold')
        
        ax.set_title('Confusion Matrix - Exploitation Type Classification', 
                    fontsize=16, fontweight='bold', pad=15)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/confusion_matrix.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_cluster_scatter(self, cluster_data: pd.DataFrame):
        """
        聚类散点图
        Cluster scatter plot with PCA
        """
        print("Creating cluster scatter visualization...")
        
        fig, ax = plt.subplots(figsize=(14, 10))
        
        # Get unique clusters
        clusters = sorted(cluster_data['cluster'].unique())
        colors = plt.cm.Set3(np.linspace(0, 1, len(clusters)))
        
        # Plot each cluster
        for cluster_id, color in zip(clusters, colors):
            cluster_points = cluster_data[cluster_data['cluster'] == cluster_id]
            
            ax.scatter(cluster_points['pca1'], cluster_points['pca2'],
                      s=200, c=[color], alpha=0.7, edgecolors='black',
                      linewidth=2, label=f'Cluster {cluster_id}')
            
            # Add country labels
            for idx, row in cluster_points.iterrows():
                ax.annotate(row['country'], 
                          (row['pca1'], row['pca2']),
                          fontsize=8, fontweight='bold',
                          xytext=(5, 5), textcoords='offset points',
                          bbox=dict(boxstyle='round,pad=0.3', 
                                  facecolor=color, 
                                  alpha=0.7))
        
        ax.set_xlabel('First Principal Component', fontsize=13, fontweight='bold')
        ax.set_ylabel('Second Principal Component', fontsize=13, fontweight='bold')
        ax.set_title('Country Clustering Based on Network Features (PCA Visualization)', 
                    fontsize=16, fontweight='bold', pad=15)
        ax.legend(loc='best', fontsize=11, framealpha=0.9)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/cluster_scatter.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_risk_heatmap(self, risk_scores: pd.DataFrame, top_n: int = 30):
        """
        风险热力图
        Risk score heatmap
        """
        print("Creating risk heatmap visualization...")
        
        top_countries = risk_scores.head(top_n)
        
        # Prepare data for heatmap
        data = top_countries[['source_risk', 'destination_risk', 'transit_risk']].values.T
        
        fig, ax = plt.subplots(figsize=(16, 6))
        
        # Plot heatmap
        im = ax.imshow(data, cmap='RdYlGn_r', aspect='auto')
        
        # Set ticks
        ax.set_xticks(np.arange(len(top_countries)))
        ax.set_yticks(np.arange(3))
        ax.set_xticklabels(top_countries['country'].values, rotation=45, ha='right')
        ax.set_yticklabels(['Source Risk', 'Destination Risk', 'Transit Risk'])
        
        # Colorbar
        cbar = ax.figure.colorbar(im, ax=ax)
        cbar.ax.set_ylabel('Risk Score', rotation=-90, va="bottom", fontsize=12)
        
        # Add text annotations
        for i in range(3):
            for j in range(len(top_countries)):
                text = ax.text(j, i, f'{data[i, j]:.0f}',
                             ha="center", va="center", color="black", fontsize=8)
        
        ax.set_title(f'Top {top_n} Countries - Trafficking Risk Analysis', 
                    fontsize=16, fontweight='bold', pad=15)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/risk_heatmap.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_network_metrics_radar(self, graph: nx.DiGraph, countries: List[str]):
        """
        雷达图 - 比较国家网络指标
        Radar chart comparing country network metrics
        """
        print("Creating radar chart for country comparison...")
        
        fig, ax = plt.subplots(figsize=(12, 12), subplot_kw=dict(projection='polar'))
        
        metrics = ['In-Degree', 'Out-Degree', 'Betweenness', 'PageRank', 'Clustering']
        angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False).tolist()
        angles += angles[:1]
        
        # Calculate metrics for each country
        betweenness = nx.betweenness_centrality(graph, weight='weight')
        pagerank = nx.pagerank(graph, weight='weight')
        clustering = nx.clustering(graph.to_undirected())
        
        colors = plt.cm.Set2(np.linspace(0, 1, len(countries)))
        
        for country, color in zip(countries[:5], colors):  # Limit to 5 countries
            if country not in graph.nodes():
                continue
            
            values = [
                graph.in_degree(country, weight='weight') / 1000,
                graph.out_degree(country, weight='weight') / 1000,
                betweenness.get(country, 0) * 100,
                pagerank.get(country, 0) * 100,
                clustering.get(country, 0)
            ]
            values += values[:1]
            
            ax.plot(angles, values, 'o-', linewidth=2, label=country, color=color)
            ax.fill(angles, values, alpha=0.25, color=color)
        
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics, fontsize=12)
        ax.set_ylim(0, max([graph.in_degree(c, weight='weight')/1000 
                           for c in countries if c in graph.nodes()] + [1]))
        ax.set_title('Network Metrics Comparison - Top Countries', 
                    fontsize=16, fontweight='bold', pad=30)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1), fontsize=11)
        ax.grid(True)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/radar_comparison.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()
    
    def plot_prediction_comparison(self, predicted_links: pd.DataFrame):
        """
        预测链接可视化
        Predicted links visualization
        """
        print("Creating predicted links visualization...")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 8))
        
        # Left: Bar chart of top predictions
        top_10 = predicted_links.head(10)
        top_10['route'] = top_10['source'] + ' → ' + top_10['target']
        
        colors = plt.cm.Reds(np.linspace(0.4, 0.9, len(top_10)))
        bars = ax1.barh(range(len(top_10)), top_10['probability'].values,
                       color=colors, edgecolor='black', linewidth=1.5)
        
        ax1.set_yticks(range(len(top_10)))
        ax1.set_yticklabels(top_10['route'].values, fontsize=11)
        ax1.set_xlabel('Prediction Probability', fontsize=12, fontweight='bold')
        ax1.set_title('Top 10 Predicted New Trafficking Routes', 
                     fontsize=14, fontweight='bold')
        ax1.invert_yaxis()
        
        # Add value labels
        for i, (bar, value) in enumerate(zip(bars, top_10['probability'].values)):
            ax1.text(value, i, f' {value:.3f}', va='center', fontsize=10, fontweight='bold')
        
        # Right: Distribution of predictions
        ax2.hist(predicted_links['probability'].values, bins=50, 
                color='steelblue', alpha=0.7, edgecolor='black')
        ax2.axvline(predicted_links['probability'].median(), 
                   color='red', linestyle='--', linewidth=2, 
                   label=f'Median: {predicted_links["probability"].median():.3f}')
        ax2.set_xlabel('Prediction Probability', fontsize=12, fontweight='bold')
        ax2.set_ylabel('Frequency', fontsize=12, fontweight='bold')
        ax2.set_title('Distribution of Prediction Probabilities', 
                     fontsize=14, fontweight='bold')
        ax2.legend(fontsize=11)
        ax2.grid(axis='y', alpha=0.3)
        
        plt.tight_layout()
        filename = f"{self.output_dir}/predicted_links.png"
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        print(f"  Saved: {filename}")
        plt.close()


def create_all_fancy_visualizations(graph: nx.DiGraph, edge_data: pd.DataFrame,
                                    model_results: Dict):
    """创建所有炫酷可视化"""
    
    print("="*70)
    print("Creating Fancy Visualizations")
    print("="*70)
    
    viz = FancyVisualizer()
    
    # 1. Circular network
    print("\n1. Circular Network Layout...")
    viz.plot_circular_network(graph, top_n=30)
    
    # 2. Hierarchical network
    print("\n2. Hierarchical Network Layout...")
    viz.plot_hierarchical_network(graph, top_n=40)
    
    # 3. Sankey flow diagram
    print("\n3. Sankey Flow Diagram...")
    viz.plot_flow_sankey(edge_data, top_n=15)
    
    # 4. ROC curves
    if 'link_prediction' in model_results:
        print("\n4. ROC Curve...")
        viz.plot_roc_curves(model_results['link_prediction'])
    
    # 5. Feature importance
    if 'link_prediction' in model_results and 'feature_importance' in model_results['link_prediction']:
        print("\n5. Feature Importance...")
        viz.plot_feature_importance(model_results['link_prediction']['feature_importance'])
    
    # 6. Confusion matrix
    if 'victim_classification' in model_results:
        print("\n6. Confusion Matrix...")
        cm = model_results['victim_classification']['confusion_matrix']
        labels = ['Labour', 'Other', 'Sexual']
        viz.plot_confusion_matrix_fancy(cm, labels)
    
    # 7. Cluster scatter
    if 'country_clustering' in model_results:
        print("\n7. Cluster Scatter Plot...")
        viz.plot_cluster_scatter(model_results['country_clustering']['data'])
    
    # 8. Risk heatmap
    if 'risk_scoring' in model_results:
        print("\n8. Risk Heatmap...")
        viz.plot_risk_heatmap(model_results['risk_scoring'], top_n=30)
    
    # 9. Radar chart
    print("\n9. Radar Chart...")
    top_countries = sorted(dict(graph.degree(weight='weight')).items(), 
                          key=lambda x: x[1], reverse=True)[:5]
    top_country_names = [c[0] for c in top_countries]
    viz.plot_network_metrics_radar(graph, top_country_names)
    
    # 10. Predicted links
    if 'predicted_links' in model_results:
        print("\n10. Predicted Links Visualization...")
        viz.plot_prediction_comparison(model_results['predicted_links'])
    
    print("\n" + "="*70)
    print("All fancy visualizations created!")
    print("="*70)


if __name__ == '__main__':
    print("="*70)
    print("Testing Improved Fancy Visualizations")
    print("="*70)
    
    from data_loader import TraffickingDataLoader
    from network_analysis import TraffickingNetworkAnalyzer
    
    # Load data
    print("\nLoading data...")
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    edge_data = loader.load_edge_data()
    
    # Create network
    print("Building network...")
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    
    # Create improved visualizations
    viz = FancyVisualizer()
    
    print("\n" + "-"*70)
    print("Generating 3 improved visualizations...")
    print("-"*70)
    
    print("\n1. Circular Network (Improved)")
    viz.plot_circular_network(analyzer.graph, top_n=25)
    
    print("\n2. Hierarchical Network (Improved)")
    viz.plot_hierarchical_network(analyzer.graph, top_n=30)
    
    print("\n3. Flow Diagram (Improved)")
    viz.plot_flow_sankey(edge_data, top_n=12)
    
    print("\n4. Geographic Flow Map")
    viz.plot_geographic_flow_map(edge_data, top_n=20)
    
    print("\n" + "="*70)
    print("✓ All improved visualizations created successfully!")
    print("="*70)
    print("\nCheck output/fancy/ folder for results:")
    print("  - circular_network_improved.png")
    print("  - hierarchical_network_improved.png")
    print("  - flow_diagram_improved.png")
    print("  - geographic_flow_map.png")
    print("\n" + "="*70)

