"""
全球人口贩运网络分析模块
Global Human Trafficking Network - Network Analysis Module
"""

import pandas as pd
import numpy as np
import networkx as nx
from typing import Dict, List, Tuple, Optional
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')


class TraffickingNetworkAnalyzer:
    """人口贩运网络分析器"""
    
    def __init__(self, edge_data: pd.DataFrame):
        """
        初始化网络分析器
        
        Args:
            edge_data: 边数据DataFrame，包含source和target列
        """
        self.edge_data = edge_data
        self.graph = None
        self.build_network()
    
    def build_network(self, weight_col: Optional[str] = None):
        """
        构建网络图
        
        Args:
            weight_col: 权重列名（如果有）
        """
        self.graph = nx.DiGraph()
        
        if weight_col and weight_col in self.edge_data.columns:
            # 带权重的边
            edges = [
                (row['source'], row['target'], {'weight': row[weight_col]})
                for _, row in self.edge_data.iterrows()
            ]
        else:
            # 计算边的频率作为权重
            edge_counts = self.edge_data.groupby(['source', 'target']).size()
            edges = [
                (source, target, {'weight': count})
                for (source, target), count in edge_counts.items()
            ]
        
        self.graph.add_edges_from(edges)
        
        print(f"网络构建完成:")
        print(f"  节点数: {self.graph.number_of_nodes()}")
        print(f"  边数: {self.graph.number_of_edges()}")
        print(f"  网络类型: {'有向图' if self.graph.is_directed() else '无向图'}")
    
    def get_basic_metrics(self) -> Dict:
        """获取基本网络指标"""
        metrics = {
            '节点数': self.graph.number_of_nodes(),
            '边数': self.graph.number_of_edges(),
            '网络密度': nx.density(self.graph),
            '是否连通': nx.is_weakly_connected(self.graph),
        }
        
        # 计算连通分量
        weak_components = list(nx.weakly_connected_components(self.graph))
        metrics['弱连通分量数'] = len(weak_components)
        metrics['最大连通分量大小'] = len(max(weak_components, key=len))
        
        return metrics
    
    def calculate_centrality(self) -> Dict[str, Dict[str, float]]:
        """
        计算各种中心性指标
        
        Returns:
            包含各种中心性指标的字典
        """
        print("计算中心性指标...")
        
        centrality_measures = {}
        
        # 度中心性
        in_degree = dict(self.graph.in_degree(weight='weight'))
        out_degree = dict(self.graph.out_degree(weight='weight'))
        
        centrality_measures['入度中心性'] = in_degree
        centrality_measures['出度中心性'] = out_degree
        
        # 介数中心性
        try:
            betweenness = nx.betweenness_centrality(self.graph, weight='weight')
            centrality_measures['介数中心性'] = betweenness
        except:
            print("  警告: 无法计算介数中心性")
        
        # 特征向量中心性（使用无向图）
        try:
            undirected_graph = self.graph.to_undirected()
            eigenvector = nx.eigenvector_centrality(
                undirected_graph, 
                max_iter=1000,
                weight='weight'
            )
            centrality_measures['特征向量中心性'] = eigenvector
        except:
            print("  警告: 无法计算特征向量中心性")
        
        # PageRank
        try:
            pagerank = nx.pagerank(self.graph, weight='weight')
            centrality_measures['PageRank'] = pagerank
        except:
            print("  警告: 无法计算PageRank")
        
        return centrality_measures
    
    def get_top_countries(self, 
                         centrality_measures: Dict[str, Dict[str, float]], 
                         top_n: int = 10) -> Dict[str, List[Tuple[str, float]]]:
        """
        获取各指标的前N个国家
        
        Args:
            centrality_measures: 中心性指标字典
            top_n: 返回前N个
            
        Returns:
            各指标的排名字典
        """
        top_countries = {}
        
        for measure_name, scores in centrality_measures.items():
            sorted_scores = sorted(
                scores.items(), 
                key=lambda x: x[1], 
                reverse=True
            )[:top_n]
            top_countries[measure_name] = sorted_scores
        
        return top_countries
    
    def identify_source_destination_transit(self) -> Dict[str, List[str]]:
        """
        识别来源国、目的国和中转国
        
        Returns:
            国家角色分类字典
        """
        roles = {
            '纯来源国': [],  # 只有出度
            '纯目的国': [],  # 只有入度
            '中转国': [],    # 既有入度又有出度
        }
        
        for node in self.graph.nodes():
            in_deg = self.graph.in_degree(node)
            out_deg = self.graph.out_degree(node)
            
            if in_deg > 0 and out_deg > 0:
                roles['中转国'].append(node)
            elif in_deg > 0 and out_deg == 0:
                roles['纯目的国'].append(node)
            elif in_deg == 0 and out_deg > 0:
                roles['纯来源国'].append(node)
        
        return roles
    
    def detect_communities(self, method: str = 'louvain') -> Dict[str, int]:
        """
        社区检测
        
        Args:
            method: 社区检测方法
            
        Returns:
            节点到社区的映射
        """
        print(f"使用{method}方法进行社区检测...")
        
        # 转换为无向图
        undirected = self.graph.to_undirected()
        
        if method == 'louvain':
            try:
                import community as community_louvain
                communities = community_louvain.best_partition(undirected)
            except ImportError:
                print("警告: python-louvain未安装，使用greedy_modularity代替")
                method = 'greedy'
        
        if method == 'greedy':
            communities_gen = nx.community.greedy_modularity_communities(
                undirected, 
                weight='weight'
            )
            communities = {}
            for i, comm in enumerate(communities_gen):
                for node in comm:
                    communities[node] = i
        
        print(f"  检测到{len(set(communities.values()))}个社区")
        
        return communities
    
    def analyze_trafficking_patterns(self) -> Dict:
        """分析贩运模式"""
        patterns = {}
        
        # 最常见的来源-目的地对
        edge_weights = [
            (u, v, d['weight']) 
            for u, v, d in self.graph.edges(data=True)
        ]
        top_routes = sorted(edge_weights, key=lambda x: x[2], reverse=True)[:20]
        patterns['前20条贩运路线'] = [
            (f"{u} → {v}", weight) 
            for u, v, weight in top_routes
        ]
        
        # 最大入度国家（主要目的国）
        in_degrees = sorted(
            self.graph.in_degree(weight='weight'), 
            key=lambda x: x[1], 
            reverse=True
        )[:10]
        patterns['前10目的国'] = in_degrees
        
        # 最大出度国家（主要来源国）
        out_degrees = sorted(
            self.graph.out_degree(weight='weight'), 
            key=lambda x: x[1], 
            reverse=True
        )[:10]
        patterns['前10来源国'] = out_degrees
        
        return patterns
    
    def get_shortest_paths_stats(self, sample_size: int = 100) -> Dict:
        """
        获取最短路径统计（采样）
        
        Args:
            sample_size: 采样大小
            
        Returns:
            路径统计字典
        """
        print(f"计算最短路径统计（采样{sample_size}对节点）...")
        
        nodes = list(self.graph.nodes())
        if len(nodes) < 2:
            return {}
        
        # 随机采样节点对
        sample_size = min(sample_size, len(nodes) * (len(nodes) - 1))
        
        path_lengths = []
        for _ in range(sample_size):
            source = np.random.choice(nodes)
            target = np.random.choice(nodes)
            
            if source != target:
                try:
                    length = nx.shortest_path_length(
                        self.graph, 
                        source=source, 
                        target=target
                    )
                    path_lengths.append(length)
                except nx.NetworkXNoPath:
                    pass
        
        if path_lengths:
            stats = {
                '平均路径长度': np.mean(path_lengths),
                '中位数路径长度': np.median(path_lengths),
                '最短路径长度': np.min(path_lengths),
                '最长路径长度': np.max(path_lengths),
                '可达路径数': len(path_lengths),
                '采样总数': sample_size,
            }
        else:
            stats = {'消息': '没有找到可达路径'}
        
        return stats


class ContinentAnalyzer:
    """大陆/区域分析器"""
    
    # 国家代码到大陆的映射（示例，可扩展）
    COUNTRY_TO_CONTINENT = {
        # 亚洲
        'CHN': 'Asia', 'IND': 'Asia', 'PAK': 'Asia', 'BGD': 'Asia', 
        'IDN': 'Asia', 'JPN': 'Asia', 'PHL': 'Asia', 'VNM': 'Asia',
        'THA': 'Asia', 'MMR': 'Asia', 'KOR': 'Asia', 'AFG': 'Asia',
        'NPL': 'Asia', 'LKA': 'Asia', 'KHM': 'Asia', 'LAO': 'Asia',
        'MYS': 'Asia', 'SGP': 'Asia', 'KAZ': 'Asia', 'UZB': 'Asia',
        'TKM': 'Asia', 'KGZ': 'Asia', 'TJK': 'Asia', 'MNG': 'Asia',
        'IRQ': 'Asia', 'SYR': 'Asia', 'YEM': 'Asia', 'JOR': 'Asia',
        'LBN': 'Asia', 'ISR': 'Asia', 'SAU': 'Asia', 'ARE': 'Asia',
        'KWT': 'Asia', 'QAT': 'Asia', 'BHR': 'Asia', 'OMN': 'Asia',
        
        # 欧洲
        'RUS': 'Europe', 'DEU': 'Europe', 'GBR': 'Europe', 'FRA': 'Europe',
        'ITA': 'Europe', 'ESP': 'Europe', 'UKR': 'Europe', 'POL': 'Europe',
        'ROU': 'Europe', 'NLD': 'Europe', 'BEL': 'Europe', 'GRC': 'Europe',
        'CZE': 'Europe', 'PRT': 'Europe', 'HUN': 'Europe', 'SWE': 'Europe',
        'AUT': 'Europe', 'BLR': 'Europe', 'SRB': 'Europe', 'CHE': 'Europe',
        'BGR': 'Europe', 'DNK': 'Europe', 'FIN': 'Europe', 'SVK': 'Europe',
        'NOR': 'Europe', 'IRL': 'Europe', 'HRV': 'Europe', 'MDA': 'Europe',
        'BIH': 'Europe', 'ALB': 'Europe', 'LTU': 'Europe', 'SVN': 'Europe',
        'LVA': 'Europe', 'EST': 'Europe', 'MKD': 'Europe', 'MNE': 'Europe',
        
        # 非洲
        'NGA': 'Africa', 'ETH': 'Africa', 'EGY': 'Africa', 'COD': 'Africa',
        'ZAF': 'Africa', 'TZA': 'Africa', 'KEN': 'Africa', 'UGA': 'Africa',
        'GHA': 'Africa', 'MOZ': 'Africa', 'MDG': 'Africa', 'CMR': 'Africa',
        'CIV': 'Africa', 'NER': 'Africa', 'MLI': 'Africa', 'BFA': 'Africa',
        'MWI': 'Africa', 'ZMB': 'Africa', 'SOM': 'Africa', 'SEN': 'Africa',
        'TCD': 'Africa', 'ZWE': 'Africa', 'RWA': 'Africa', 'BDI': 'Africa',
        'TUN': 'Africa', 'GIN': 'Africa', 'SSD': 'Africa', 'BEN': 'Africa',
        'TGO': 'Africa', 'SLE': 'Africa', 'LBY': 'Africa', 'LBR': 'Africa',
        'MRT': 'Africa', 'GAB': 'Africa', 'NAM': 'Africa', 'BWA': 'Africa',
        
        # 北美洲
        'USA': 'North America', 'MEX': 'North America', 'CAN': 'North America',
        'GTM': 'North America', 'CUB': 'North America', 'HTI': 'North America',
        'DOM': 'North America', 'HND': 'North America', 'NIC': 'North America',
        'SLV': 'North America', 'CRI': 'North America', 'PAN': 'North America',
        'JAM': 'North America', 'TTO': 'North America',
        
        # 南美洲
        'BRA': 'South America', 'COL': 'South America', 'ARG': 'South America',
        'PER': 'South America', 'VEN': 'South America', 'CHL': 'South America',
        'ECU': 'South America', 'BOL': 'South America', 'PRY': 'South America',
        'URY': 'South America', 'GUY': 'South America', 'SUR': 'South America',
        
        # 大洋洲
        'AUS': 'Oceania', 'NZL': 'Oceania', 'PNG': 'Oceania', 'FJI': 'Oceania',
    }
    
    @classmethod
    def get_continent(cls, country_code: str) -> str:
        """获取国家所属大陆"""
        return cls.COUNTRY_TO_CONTINENT.get(country_code, 'Unknown')
    
    @classmethod
    def analyze_cross_continent_trafficking(cls, 
                                           edge_data: pd.DataFrame) -> Dict:
        """
        分析跨大陆贩运模式
        
        Args:
            edge_data: 边数据
            
        Returns:
            跨大陆分析结果
        """
        # 添加大陆信息
        edge_data['source_continent'] = edge_data['source'].apply(cls.get_continent)
        edge_data['target_continent'] = edge_data['target'].apply(cls.get_continent)
        
        # 判断是否跨大陆
        edge_data['is_cross_continent'] = (
            edge_data['source_continent'] != edge_data['target_continent']
        )
        
        # 统计
        total = len(edge_data)
        within_continent = (~edge_data['is_cross_continent']).sum()
        cross_continent = edge_data['is_cross_continent'].sum()
        
        analysis = {
            '总边数': total,
            '大陆内部贩运': within_continent,
            '跨大陆贩运': cross_continent,
            '大陆内部比例': within_continent / total if total > 0 else 0,
            '跨大陆比例': cross_continent / total if total > 0 else 0,
        }
        
        # 各大陆内部贩运统计
        continent_internal = edge_data[
            ~edge_data['is_cross_continent']
        ]['source_continent'].value_counts().to_dict()
        analysis['各大陆内部贩运数量'] = continent_internal
        
        # 跨大陆路线统计
        cross_routes = edge_data[
            edge_data['is_cross_continent']
        ].groupby(['source_continent', 'target_continent']).size()
        analysis['跨大陆路线'] = cross_routes.to_dict()
        
        return analysis


if __name__ == '__main__':
    print("="*60)
    print("全球人口贩运网络分析 - 网络分析测试")
    print("="*60)
    
    # 导入数据加载器
    from data_loader import TraffickingDataLoader
    
    # 加载数据
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    edge_data = loader.load_edge_data()
    
    # 创建网络分析器
    print("\n1. 构建网络...")
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    
    # 基本指标
    print("\n2. 基本网络指标:")
    basic_metrics = analyzer.get_basic_metrics()
    for key, value in basic_metrics.items():
        print(f"  {key}: {value}")
    
    # 中心性分析
    print("\n3. 中心性分析...")
    centrality = analyzer.calculate_centrality()
    top_countries = analyzer.get_top_countries(centrality, top_n=5)
    
    for measure, countries in top_countries.items():
        print(f"\n  {measure} - 前5名:")
        for country, score in countries:
            print(f"    {country}: {score:.4f}")
    
    # 角色识别
    print("\n4. 国家角色识别:")
    roles = analyzer.identify_source_destination_transit()
    for role, countries in roles.items():
        print(f"  {role}: {len(countries)}个")
        if countries:
            print(f"    示例: {countries[:5]}")
    
    # 贩运模式
    print("\n5. 贩运模式分析:")
    patterns = analyzer.analyze_trafficking_patterns()
    print(f"\n  前5条主要贩运路线:")
    for route, weight in patterns['前20条贩运路线'][:5]:
        print(f"    {route}: {weight}次")
    
    # 大陆分析
    print("\n6. 大陆/区域分析:")
    continent_analysis = ContinentAnalyzer.analyze_cross_continent_trafficking(
        edge_data.copy()
    )
    print(f"  大陆内部贩运比例: {continent_analysis['大陆内部比例']:.2%}")
    print(f"  跨大陆贩运比例: {continent_analysis['跨大陆比例']:.2%}")
    
    print("\n网络分析测试完成！")

