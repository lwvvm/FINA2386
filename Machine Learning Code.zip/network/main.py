"""
全球人口贩运网络分析 - 主执行脚本
Global Human Trafficking Network Analysis - Main Execution Script
"""

import sys
import json
from datetime import datetime
from data_loader import TraffickingDataLoader, DataPreprocessor
from network_analysis import TraffickingNetworkAnalyzer, ContinentAnalyzer
from hypothesis_testing import HypothesisTester
from visualization import NetworkVisualizer


def print_section(title):
    """打印分节标题"""
    print("\n" + "="*70)
    print(f"{title:^70}")
    print("="*70)


def save_results_to_json(results: dict, filename: str):
    """保存结果为JSON文件"""
    # 转换numpy类型为Python原生类型
    def convert_types(obj):
        import numpy as np
        import pandas as pd
        
        if isinstance(obj, (np.integer, np.int64, np.int32)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64, np.float32)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, pd.Series):
            return convert_types(obj.to_dict())
        elif isinstance(obj, pd.DataFrame):
            return convert_types(obj.to_dict())
        elif isinstance(obj, dict):
            return {str(key): convert_types(value) for key, value in obj.items()}
        elif isinstance(obj, (list, tuple)):
            return [convert_types(item) for item in obj]
        elif isinstance(obj, tuple):
            return tuple(convert_types(item) for item in obj)
        elif pd.isna(obj):
            return None
        else:
            return obj
    
    results_converted = convert_types(results)
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(results_converted, f, ensure_ascii=False, indent=2)
    
    print(f"\n结果已保存到: {filename}")


def main():
    """主函数"""
    print_section("全球人口贩运网络分析系统")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # ========== 1. 数据加载 ==========
    print_section("步骤 1: 数据加载与预处理")
    
    data_file = 'CTDC_global_synthetic_data_v2025.xlsx'
    loader = TraffickingDataLoader(data_file)
    
    print("\n加载数据...")
    loader.load_all_sheets()
    
    edge_data = loader.load_edge_data()
    print(f"✓ 边数据已加载: {edge_data.shape}")
    
    victim_data = loader.load_victim_data()
    print(f"✓ 受害者数据已加载: {victim_data.shape}")
    
    # 数据预处理
    print("\n数据预处理...")
    preprocessor = DataPreprocessor()
    victim_data = preprocessor.clean_victim_data(victim_data)
    victim_data = preprocessor.create_age_groups(victim_data)
    victim_data = preprocessor.extract_exploitation_types(victim_data)
    print("✓ 数据预处理完成")
    
    # 基本统计
    print("\n基本统计信息:")
    net_stats = loader.get_network_statistics()
    victim_stats = loader.get_victim_statistics()
    
    print(f"  网络节点数: {net_stats['总国家数']}")
    print(f"  贩运路线数: {net_stats['总边数']}")
    print(f"  受害者记录数: {victim_stats['总受害者数']}")
    print(f"  时间跨度: {victim_stats['年份范围']}")
    
    # ========== 2. 网络分析 ==========
    print_section("步骤 2: 网络结构分析")
    
    print("\n构建网络图...")
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    
    print("\n基本网络指标:")
    basic_metrics = analyzer.get_basic_metrics()
    for key, value in basic_metrics.items():
        if key not in ['来源国列表', '目的国列表']:
            print(f"  {key}: {value}")
    
    print("\n计算中心性指标...")
    centrality = analyzer.calculate_centrality()
    top_countries = analyzer.get_top_countries(centrality, top_n=10)
    
    print("\n关键国家识别:")
    for measure, countries in top_countries.items():
        print(f"\n  {measure} - 前5名:")
        for country, score in countries[:5]:
            print(f"    {country}: {score:.4f}")
    
    print("\n识别国家角色...")
    roles = analyzer.identify_source_destination_transit()
    for role, countries in roles.items():
        print(f"  {role}: {len(countries)}个国家")
    
    print("\n分析贩运模式...")
    patterns = analyzer.analyze_trafficking_patterns()
    print(f"  识别出前20条主要贩运路线")
    print(f"  前3条路线:")
    for route, weight in patterns['前20条贩运路线'][:3]:
        print(f"    {route}: {weight}次")
    
    # 大陆分析
    print("\n地理分布分析...")
    continent_analysis = ContinentAnalyzer.analyze_cross_continent_trafficking(
        edge_data.copy()
    )
    print(f"  大陆内部贩运: {continent_analysis['大陆内部比例']:.1%}")
    print(f"  跨大陆贩运: {continent_analysis['跨大陆比例']:.1%}")
    
    # ========== 3. 假设测试 ==========
    print_section("步骤 3: 假设测试")
    
    tester = HypothesisTester(victim_data, edge_data)
    hypothesis_results = tester.run_all_tests()
    
    # ========== 4. 可视化 ==========
    print_section("步骤 4: 生成可视化图表")
    
    viz = NetworkVisualizer(output_dir='output')
    
    print("\n生成网络可视化...")
    viz.plot_network_graph(
        analyzer.graph, 
        title="Global_Human_Trafficking_Network", 
        top_n=50
    )
    
    print("\n生成中心性分析图...")
    viz.plot_centrality_rankings(centrality, top_n=15)
    
    print("\n生成受害者人口统计图...")
    viz.plot_victim_demographics(victim_data)
    
    print("\n生成贩运路线图...")
    viz.plot_trafficking_routes(edge_data, top_n=20)
    
    print("\n生成地理分布图...")
    viz.plot_continent_analysis(continent_analysis)
    
    print("\n生成年份趋势图...")
    viz.plot_year_trend(victim_data)
    
    print("\n生成假设测试结果图...")
    viz.plot_hypothesis_results(hypothesis_results)
    
    # ========== 5. 生成报告 ==========
    print_section("步骤 5: 生成分析报告")
    
    # 整合所有结果
    all_results = {
        'metadata': {
            '分析时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '数据文件': data_file,
        },
        'data_summary': {
            '网络统计': net_stats,
            '受害者统计': victim_stats,
        },
        'network_analysis': {
            '基本指标': basic_metrics,
            '中心性排名': {
                measure: dict(list(top_countries[measure])) 
                for measure in top_countries
            },
            '国家角色': {k: len(v) for k, v in roles.items()},
            '贩运模式': patterns,
            '地理分布': continent_analysis,
        },
        'hypothesis_testing': hypothesis_results,
    }
    
    # 保存JSON结果
    save_results_to_json(all_results, 'output/analysis_results.json')
    
    # 生成文本报告
    generate_text_report(all_results, hypothesis_results)
    
    print_section("分析完成")
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\n所有结果已保存到 output/ 目录")
    print("  - 分析结果: output/analysis_results.json")
    print("  - 详细报告: output/analysis_report.txt")
    print("  - 可视化图表: output/*.png")


def generate_text_report(results: dict, hypothesis_results: dict):
    """生成文本格式的分析报告"""
    
    report = []
    report.append("="*70)
    report.append("全球人口贩运网络分析报告".center(70))
    report.append("Global Human Trafficking Network Analysis Report".center(70))
    report.append("="*70)
    report.append("")
    
    report.append(f"生成时间: {results['metadata']['分析时间']}")
    report.append(f"数据来源: {results['metadata']['数据文件']}")
    report.append("")
    
    # 执行摘要
    report.append("-"*70)
    report.append("执行摘要 (Executive Summary)")
    report.append("-"*70)
    report.append("")
    report.append("本研究基于全球人口贩运数据，构建并分析了跨国人口贩运网络，")
    report.append("测试了三个核心假设，并识别了关键的贩运模式和脆弱性因素。")
    report.append("")
    
    # 数据概览
    report.append("-"*70)
    report.append("1. 数据概览")
    report.append("-"*70)
    report.append("")
    
    net_stats = results['data_summary']['网络统计']
    victim_stats = results['data_summary']['受害者统计']
    
    report.append(f"网络规模:")
    report.append(f"  - 国家数量: {net_stats['总国家数']}")
    report.append(f"  - 来源国: {net_stats['来源国数量']}")
    report.append(f"  - 目的国: {net_stats['目的国数量']}")
    report.append(f"  - 贩运路线: {net_stats['总边数']}")
    report.append("")
    
    report.append(f"受害者数据:")
    report.append(f"  - 总记录数: {victim_stats['总受害者数']}")
    report.append(f"  - 时间跨度: {victim_stats['年份范围'][0]:.0f} - {victim_stats['年份范围'][1]:.0f}")
    report.append("")
    
    if '性别分布' in victim_stats:
        report.append("  性别分布:")
        for gender, count in victim_stats['性别分布'].items():
            pct = count / victim_stats['总受害者数'] * 100
            report.append(f"    - {gender}: {count} ({pct:.1f}%)")
        report.append("")
    
    if '剥削类型分布' in victim_stats:
        report.append("  剥削类型:")
        for type_name, count in victim_stats['剥削类型分布']:
            report.append(f"    - {type_name}: {count}")
        report.append("")
    
    # 网络分析结果
    report.append("-"*70)
    report.append("2. 网络结构分析")
    report.append("-"*70)
    report.append("")
    
    basic = results['network_analysis']['基本指标']
    report.append(f"网络特征:")
    report.append(f"  - 网络密度: {basic['网络密度']:.4f}")
    report.append(f"  - 弱连通分量数: {basic['弱连通分量数']}")
    report.append(f"  - 最大连通分量大小: {basic['最大连通分量大小']}")
    report.append("")
    
    report.append("关键国家（基于不同中心性指标）:")
    report.append("")
    
    centrality_rankings = results['network_analysis']['中心性排名']
    for measure, scores in centrality_rankings.items():
        report.append(f"  {measure} - 前5名:")
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:5]
        for country, score in sorted_scores:
            report.append(f"    {country}: {score:.4f}")
        report.append("")
    
    # 国家角色
    roles = results['network_analysis']['国家角色']
    report.append("国家角色分类:")
    for role, count in roles.items():
        report.append(f"  - {role}: {count}个")
    report.append("")
    
    # 地理分析
    geo = results['network_analysis']['地理分布']
    report.append("地理分布特征:")
    report.append(f"  - 大陆内部贩运: {geo['大陆内部贩运']}条路线 ({geo['大陆内部比例']*100:.1f}%)")
    report.append(f"  - 跨大陆贩运: {geo['跨大陆贩运']}条路线 ({geo['跨大陆比例']*100:.1f}%)")
    report.append("")
    
    # 假设测试结果
    report.append("-"*70)
    report.append("3. 假设测试结果")
    report.append("-"*70)
    report.append("")
    
    for i in range(1, 4):
        hyp_key = f'假设{i}'
        if hyp_key in hypothesis_results:
            hyp = hypothesis_results[hyp_key]
            report.append(f"{hyp_key}:")
            report.append(f"  假设内容: {hyp['假设']}")
            report.append(f"  支持度: {hyp['假设支持度']}")
            report.append(f"  结论: {hyp['结论']}")
            report.append("")
    
    # 主要发现
    report.append("-"*70)
    report.append("4. 主要发现 (Key Findings)")
    report.append("-"*70)
    report.append("")
    
    findings = generate_key_findings(results, hypothesis_results)
    for i, finding in enumerate(findings, 1):
        report.append(f"{i}. {finding}")
        report.append("")
    
    # 政策建议
    report.append("-"*70)
    report.append("5. 政策建议 (Policy Recommendations)")
    report.append("-"*70)
    report.append("")
    
    recommendations = generate_recommendations(results, hypothesis_results)
    for i, rec in enumerate(recommendations, 1):
        report.append(f"{i}. {rec}")
        report.append("")
    
    # 研究局限
    report.append("-"*70)
    report.append("6. 研究局限 (Limitations)")
    report.append("-"*70)
    report.append("")
    report.append("1. 数据基于报告的案例，可能存在显著的未报告偏差")
    report.append("2. 国家间的报告标准和执法力度差异可能影响数据代表性")
    report.append("3. 地理距离分析基于大陆分类，未考虑实际物理距离")
    report.append("4. 经济数据未包含在当前分析中，限制了经济相似性的评估")
    report.append("")
    
    report.append("="*70)
    report.append("报告结束".center(70))
    report.append("="*70)
    
    # 保存报告
    report_text = '\n'.join(report)
    with open('output/analysis_report.txt', 'w', encoding='utf-8') as f:
        f.write(report_text)
    
    print("\n✓ 文本报告已生成: output/analysis_report.txt")


def generate_key_findings(results: dict, hypothesis_results: dict) -> list:
    """生成主要发现"""
    findings = []
    
    # 网络结构发现
    basic = results['network_analysis']['基本指标']
    if basic['网络密度'] < 0.1:
        findings.append(
            f"网络呈现稀疏结构（密度={basic['网络密度']:.4f}），"
            "表明人口贩运路线相对集中而非随机分布。"
        )
    
    # 地理发现
    geo = results['network_analysis']['地理分布']
    if geo['大陆内部比例'] > 0.6:
        findings.append(
            f"约{geo['大陆内部比例']*100:.0f}%的贩运发生在同一大陆内，"
            "强烈支持地理临近性在贩运路线中的重要作用。"
        )
    
    # 性别发现
    victim_stats = results['data_summary']['受害者统计']
    if '性别分布' in victim_stats:
        gender_dist = victim_stats['性别分布']
        if 'Woman' in gender_dist:
            woman_count = gender_dist['Woman']
            woman_pct = woman_count / victim_stats['总受害者数'] * 100
            if woman_pct > 50:
                findings.append(
                    f"女性受害者占{woman_pct:.1f}%，显示性别在人口贩运脆弱性中的关键作用。"
                )
    
    # 假设测试发现
    for i in range(1, 4):
        hyp_key = f'假设{i}'
        if hyp_key in hypothesis_results:
            hyp = hypothesis_results[hyp_key]
            if hyp['假设支持度'] in ['强支持', '中等支持']:
                findings.append(f"{hyp_key}得到{hyp['假设支持度']}：{hyp['结论']}")
    
    return findings


def generate_recommendations(results: dict, hypothesis_results: dict) -> list:
    """生成政策建议"""
    recommendations = []
    
    # 基于地理发现的建议
    geo = results['network_analysis']['地理分布']
    if geo['大陆内部比例'] > 0.6:
        recommendations.append(
            "加强区域合作：由于大部分贩运发生在区域内，"
            "应优先建立和强化区域反贩运合作机制和信息共享平台。"
        )
    
    # 基于性别发现的建议
    victim_stats = results['data_summary']['受害者统计']
    if '性别分布' in victim_stats and 'Woman' in victim_stats['性别分布']:
        woman_pct = victim_stats['性别分布']['Woman'] / victim_stats['总受害者数'] * 100
        if woman_pct > 50:
            recommendations.append(
                "针对性保护措施：设计专门针对女性的预防和保护计划，"
                "特别关注性剥削风险高的群体。"
            )
    
    # 基于网络中心性的建议
    recommendations.append(
        "重点监控关键节点：识别出的高中心性国家应成为国际反贩运努力的重点，"
        "在这些关键节点加强执法和监控可能产生最大的网络干预效果。"
    )
    
    # 基于剥削类型的建议
    recommendations.append(
        "多维度干预策略：不同剥削类型需要不同的干预方法，"
        "应针对强制劳动和性剥削分别制定专项行动计划。"
    )
    
    # 数据和研究建议
    recommendations.append(
        "改进数据收集：建立标准化的跨国数据收集机制，"
        "提高数据质量和可比性，为政策制定提供更可靠的证据基础。"
    )
    
    return recommendations


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n程序被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n错误: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

