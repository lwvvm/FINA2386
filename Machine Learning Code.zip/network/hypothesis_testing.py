"""
全球人口贩运网络 - 假设测试模块
Global Human Trafficking Network - Hypothesis Testing Module

测试三个假设:
1. 相同剥削类型的国家在地理/经济条件上更相似
2. 18-30岁的年轻成年人更容易受影响，女性风险最高
3. 贩运路线倾向于较短的地理距离（例如同一大陆内）
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from scipy import stats
from sklearn.metrics import silhouette_score
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')


class HypothesisTester:
    """假设测试器"""
    
    def __init__(self, victim_data: pd.DataFrame, edge_data: pd.DataFrame):
        """
        初始化假设测试器
        
        Args:
            victim_data: 受害者数据
            edge_data: 边数据
        """
        self.victim_data = victim_data
        self.edge_data = edge_data
        self.results = {}
    
    def test_hypothesis_1(self) -> Dict:
        """
        假设1: 遭受相同剥削类型的国家在地理或经济条件上更相似
        
        方法:
        - 按剥削类型分组国家
        - 分析每组内国家的地理分布（大陆分布）
        - 计算组内相似性
        """
        print("\n" + "="*60)
        print("假设1测试: 相同剥削类型国家的相似性分析")
        print("="*60)
        
        from network_analysis import ContinentAnalyzer
        
        results = {
            '假设': '遭受相同剥削类型的国家在地理或经济条件上更相似',
            '测试方法': '分析不同剥削类型受害者的来源国地理分布',
            '详细分析': {}
        }
        
        # 确定每个国家的主要剥削类型
        exploitation_types = ['isForcedLabour', 'isSexualExploit', 'isOtherExploit']
        
        for exploit_type in exploitation_types:
            if exploit_type not in self.victim_data.columns:
                continue
            
            type_name = {
                'isForcedLabour': '强制劳动',
                'isSexualExploit': '性剥削',
                'isOtherExploit': '其他剥削'
            }[exploit_type]
            
            print(f"\n分析 {type_name}...")
            
            # 筛选该类型的受害者
            victims = self.victim_data[
                self.victim_data[exploit_type] == 1
            ].copy()
            
            if len(victims) == 0:
                continue
            
            # 获取来源国和目的国
            source_countries = victims['citizenship'].value_counts()
            target_countries = victims['CountryOfExploitation'].value_counts()
            
            # 分析来源国的地理分布
            source_continents = defaultdict(int)
            for country, count in source_countries.items():
                continent = ContinentAnalyzer.get_continent(str(country))
                source_continents[continent] += count
            
            # 分析目的国的地理分布
            target_continents = defaultdict(int)
            for country, count in target_countries.items():
                continent = ContinentAnalyzer.get_continent(str(country))
                target_continents[continent] += count
            
            # 计算地理集中度（使用赫芬达尔指数）
            source_total = sum(source_continents.values())
            source_hhi = sum(
                (count/source_total)**2 for count in source_continents.values()
            ) if source_total > 0 else 0
            
            target_total = sum(target_continents.values())
            target_hhi = sum(
                (count/target_total)**2 for count in target_continents.values()
            ) if target_total > 0 else 0
            
            # 存储结果
            results['详细分析'][type_name] = {
                '受害者数量': len(victims),
                '来源国数量': len(source_countries),
                '目的国数量': len(target_countries),
                '来源国地理分布': dict(source_continents),
                '目的国地理分布': dict(target_continents),
                '来源国集中度(HHI)': source_hhi,
                '目的国集中度(HHI)': target_hhi,
                '主要来源大陆': max(source_continents.items(), key=lambda x: x[1])[0] if source_continents else 'N/A',
                '主要目的大陆': max(target_continents.items(), key=lambda x: x[1])[0] if target_continents else 'N/A',
            }
            
            print(f"  受害者数量: {len(victims)}")
            print(f"  来源国集中度: {source_hhi:.3f}")
            print(f"  目的国集中度: {target_hhi:.3f}")
            print(f"  主要来源大陆: {results['详细分析'][type_name]['主要来源大陆']}")
            print(f"  主要目的大陆: {results['详细分析'][type_name]['主要目的大陆']}")
        
        # 结论
        if results['详细分析']:
            # 比较不同剥削类型的地理集中度
            hhis = [
                data['来源国集中度(HHI)'] 
                for data in results['详细分析'].values()
            ]
            avg_hhi = np.mean(hhis)
            
            results['结论'] = (
                f"不同剥削类型显示出不同的地理分布模式。"
                f"平均地理集中度为{avg_hhi:.3f}。"
                f"集中度 > 0.2 表示较强的地理聚集性，"
                f"支持相同剥削类型国家在地理上更相似的假设。"
            )
            
            if avg_hhi > 0.2:
                results['假设支持度'] = '强支持'
            elif avg_hhi > 0.15:
                results['假设支持度'] = '中等支持'
            else:
                results['假设支持度'] = '弱支持'
        else:
            results['结论'] = '数据不足以测试此假设'
            results['假设支持度'] = '无法确定'
        
        print(f"\n结论: {results['结论']}")
        print(f"假设支持度: {results['假设支持度']}")
        
        self.results['假设1'] = results
        return results
    
    def test_hypothesis_2(self) -> Dict:
        """
        假设2: 18-30岁的年轻成年人更容易受影响，该年龄段女性风险最高
        
        方法:
        - 分析不同年龄段的受害者分布
        - 分析不同性别在各年龄段的分布
        - 使用卡方检验测试显著性
        """
        print("\n" + "="*60)
        print("假设2测试: 年龄和性别风险分析")
        print("="*60)
        
        results = {
            '假设': '18-30岁的年轻成年人更容易受影响，该年龄段女性风险最高',
            '测试方法': '分析年龄段和性别分布，使用统计检验',
            '详细分析': {}
        }
        
        df = self.victim_data.copy()
        
        # 年龄段分析
        print("\n1. 年龄段分布分析...")
        if 'ageBroad' in df.columns:
            age_dist = df['ageBroad'].value_counts()
            age_dist_pct = df['ageBroad'].value_counts(normalize=True) * 100
            
            results['详细分析']['年龄段分布'] = {
                '绝对数量': age_dist.to_dict(),
                '百分比': {k: f"{v:.2f}%" for k, v in age_dist_pct.items()}
            }
            
            print("  年龄段分布:")
            for age, pct in age_dist_pct.items():
                print(f"    {age}: {pct:.2f}%")
            
            # 识别18-30岁组
            age_18_30_keywords = ['adult', '18', '19', '20', '21-29', '30', 'young']
            total_victims = len(df)
            young_adult_count = 0
            
            for age_group in age_dist.index:
                age_str = str(age_group).lower()
                if any(keyword in age_str for keyword in age_18_30_keywords):
                    young_adult_count += age_dist[age_group]
            
            young_adult_pct = (young_adult_count / total_victims * 100) if total_victims > 0 else 0
            
            results['详细分析']['18-30岁占比'] = f"{young_adult_pct:.2f}%"
            print(f"\n  估计18-30岁占比: {young_adult_pct:.2f}%")
        
        # 性别分析
        print("\n2. 性别分布分析...")
        if 'gender' in df.columns:
            gender_dist = df['gender'].value_counts()
            gender_dist_pct = df['gender'].value_counts(normalize=True) * 100
            
            results['详细分析']['性别分布'] = {
                '绝对数量': gender_dist.to_dict(),
                '百分比': {k: f"{v:.2f}%" for k, v in gender_dist_pct.items()}
            }
            
            print("  性别分布:")
            for gender, pct in gender_dist_pct.items():
                print(f"    {gender}: {pct:.2f}%")
        
        # 年龄和性别交叉分析
        print("\n3. 年龄-性别交叉分析...")
        if 'ageBroad' in df.columns and 'gender' in df.columns:
            cross_tab = pd.crosstab(
                df['ageBroad'], 
                df['gender'], 
                normalize='index'
            ) * 100
            
            results['详细分析']['年龄性别交叉表'] = cross_tab.to_dict()
            
            print("  各年龄段性别比例:")
            print(cross_tab.round(2))
            
            # 卡方检验
            chi2_tab = pd.crosstab(df['ageBroad'], df['gender'])
            chi2, p_value, dof, expected = stats.chi2_contingency(chi2_tab)
            
            results['详细分析']['卡方检验'] = {
                'chi2统计量': float(chi2),
                'p值': float(p_value),
                '自由度': int(dof),
                '显著性': 'Yes' if p_value < 0.05 else 'No'
            }
            
            print(f"\n  卡方检验: χ² = {chi2:.2f}, p = {p_value:.4f}")
            print(f"  {'显著' if p_value < 0.05 else '不显著'}的年龄-性别关联")
        
        # 剥削类型与年龄/性别的关系
        print("\n4. 剥削类型与人口统计特征的关系...")
        exploitation_cols = ['isForcedLabour', 'isSexualExploit', 'isOtherExploit']
        
        for col in exploitation_cols:
            if col not in df.columns:
                continue
            
            type_name = {
                'isForcedLabour': '强制劳动',
                'isSexualExploit': '性剥削',
                'isOtherExploit': '其他剥削'
            }[col]
            
            exploit_victims = df[df[col] == 1]
            
            if len(exploit_victims) > 0 and 'gender' in df.columns:
                gender_in_exploit = exploit_victims['gender'].value_counts(
                    normalize=True
                ) * 100
                
                if type_name not in results['详细分析']:
                    results['详细分析'][type_name] = {}
                
                results['详细分析'][type_name]['性别分布'] = {
                    k: f"{v:.2f}%" for k, v in gender_in_exploit.items()
                }
                
                print(f"\n  {type_name}中的性别分布:")
                for gender, pct in gender_in_exploit.items():
                    print(f"    {gender}: {pct:.2f}%")
        
        # 结论
        conclusions = []
        
        if 'ageBroad' in df.columns:
            if young_adult_pct > 40:  # 如果18-30岁占比超过40%
                conclusions.append(f"年轻成年人（18-30岁）占{young_adult_pct:.1f}%，支持该年龄段更易受影响的假设")
            else:
                conclusions.append(f"年轻成年人占{young_adult_pct:.1f}%，未显示明显的年龄偏好")
        
        if 'gender' in df.columns and 'Woman' in gender_dist.index:
            woman_pct = gender_dist_pct.get('Woman', 0)
            if woman_pct > 50:
                conclusions.append(f"女性受害者占{woman_pct:.1f}%，支持女性风险更高的假设")
            else:
                conclusions.append(f"女性受害者占{woman_pct:.1f}%")
        
        if '性剥削' in results['详细分析']:
            sex_exploit_gender = results['详细分析']['性剥削'].get('性别分布', {})
            woman_in_sex = float(sex_exploit_gender.get('Woman', '0%').rstrip('%'))
            if woman_in_sex > 70:
                conclusions.append(f"性剥削中女性占{woman_in_sex:.1f}%，显著高于其他类型")
        
        results['结论'] = ' | '.join(conclusions) if conclusions else '数据不足以得出结论'
        
        # 评估假设支持度
        support_score = 0
        if young_adult_pct > 40:
            support_score += 1
        if 'gender' in df.columns and gender_dist_pct.get('Woman', 0) > 50:
            support_score += 1
        if p_value < 0.05 if 'ageBroad' in df.columns and 'gender' in df.columns else False:
            support_score += 1
        
        if support_score >= 2:
            results['假设支持度'] = '强支持'
        elif support_score == 1:
            results['假设支持度'] = '中等支持'
        else:
            results['假设支持度'] = '弱支持'
        
        print(f"\n结论: {results['结论']}")
        print(f"假设支持度: {results['假设支持度']}")
        
        self.results['假设2'] = results
        return results
    
    def test_hypothesis_3(self) -> Dict:
        """
        假设3: 贩运路线倾向于较短的地理距离（例如同一大陆内）
        
        方法:
        - 计算同大陆 vs 跨大陆贩运的比例
        - 分析地理距离模式
        - 使用统计检验
        """
        print("\n" + "="*60)
        print("假设3测试: 地理距离和贩运路线分析")
        print("="*60)
        
        from network_analysis import ContinentAnalyzer
        
        results = {
            '假设': '贩运路线倾向于较短的地理距离（例如同一大陆内）',
            '测试方法': '分析同大陆内 vs 跨大陆贩运的比例',
            '详细分析': {}
        }
        
        # 使用ContinentAnalyzer分析
        print("\n分析贩运路线的地理模式...")
        continent_analysis = ContinentAnalyzer.analyze_cross_continent_trafficking(
            self.edge_data.copy()
        )
        
        results['详细分析']['总体统计'] = {
            '总边数': continent_analysis['总边数'],
            '大陆内部贩运': continent_analysis['大陆内部贩运'],
            '跨大陆贩运': continent_analysis['跨大陆贩运'],
            '大陆内部比例': f"{continent_analysis['大陆内部比例']*100:.2f}%",
            '跨大陆比例': f"{continent_analysis['跨大陆比例']*100:.2f}%",
        }
        
        print(f"\n总体统计:")
        print(f"  总边数: {continent_analysis['总边数']}")
        print(f"  大陆内部贩运: {continent_analysis['大陆内部贩运']} ({continent_analysis['大陆内部比例']*100:.2f}%)")
        print(f"  跨大陆贩运: {continent_analysis['跨大陆贩运']} ({continent_analysis['跨大陆比例']*100:.2f}%)")
        
        # 各大陆内部贩运统计
        results['详细分析']['各大陆内部贩运'] = continent_analysis['各大陆内部贩运数量']
        
        print(f"\n各大陆内部贩运数量:")
        for continent, count in continent_analysis['各大陆内部贩运数量'].items():
            if continent != 'Unknown':
                print(f"  {continent}: {count}")
        
        # 跨大陆路线
        results['详细分析']['主要跨大陆路线'] = {}
        if continent_analysis['跨大陆路线']:
            sorted_routes = sorted(
                continent_analysis['跨大陆路线'].items(),
                key=lambda x: x[1],
                reverse=True
            )[:10]
            
            print(f"\n前10条跨大陆路线:")
            for (source, target), count in sorted_routes:
                route_name = f"{source} → {target}"
                results['详细分析']['主要跨大陆路线'][route_name] = count
                print(f"  {route_name}: {count}")
        
        # 二项检验：测试大陆内部比例是否显著高于50%
        within_continent = continent_analysis['大陆内部贩运']
        total = continent_analysis['总边数']
        
        if total > 0:
            # 进行二项检验（兼容新旧版本scipy）
            try:
                # 新版本scipy (>= 1.7)
                from scipy.stats import binomtest
                binom_result = binomtest(
                    within_continent,
                    total,
                    p=0.5,
                    alternative='greater'
                )
                binom_test = binom_result.pvalue
            except ImportError:
                # 旧版本scipy
                binom_test = stats.binom_test(
                    within_continent,
                    total,
                    p=0.5,
                    alternative='greater'
                )
            
            results['详细分析']['统计检验'] = {
                '检验方法': '二项检验',
                '零假设': '大陆内部贩运比例 = 50%',
                '备择假设': '大陆内部贩运比例 > 50%',
                'p值': float(binom_test),
                '显著性水平': 'p < 0.05',
                '结果': '拒绝零假设' if binom_test < 0.05 else '不能拒绝零假设'
            }
            
            print(f"\n统计检验（二项检验）:")
            print(f"  p值: {binom_test:.6f}")
            print(f"  结果: {results['详细分析']['统计检验']['结果']}")
        
        # 从受害者数据验证
        print("\n从受害者数据验证...")
        if 'citizenship' in self.victim_data.columns and 'CountryOfExploitation' in self.victim_data.columns:
            victim_df = self.victim_data[
                ['citizenship', 'CountryOfExploitation']
            ].dropna().copy()
            
            victim_df['source_continent'] = victim_df['citizenship'].apply(
                ContinentAnalyzer.get_continent
            )
            victim_df['target_continent'] = victim_df['CountryOfExploitation'].apply(
                ContinentAnalyzer.get_continent
            )
            
            victim_df['is_same_continent'] = (
                victim_df['source_continent'] == victim_df['target_continent']
            )
            
            same_continent_victims = victim_df['is_same_continent'].sum()
            total_victims = len(victim_df)
            same_continent_pct = (same_continent_victims / total_victims * 100) if total_victims > 0 else 0
            
            results['详细分析']['受害者数据验证'] = {
                '总受害者数': total_victims,
                '同大陆受害者': same_continent_victims,
                '同大陆比例': f"{same_continent_pct:.2f}%"
            }
            
            print(f"  同大陆受害者比例: {same_continent_pct:.2f}%")
        
        # 结论
        within_pct = continent_analysis['大陆内部比例'] * 100
        
        if within_pct > 60 and (binom_test < 0.05 if total > 0 else False):
            conclusion = f"大陆内部贩运占{within_pct:.1f}%，且统计上显著高于随机水平，强烈支持假设"
            support_level = '强支持'
        elif within_pct > 50:
            conclusion = f"大陆内部贩运占{within_pct:.1f}%，支持假设"
            support_level = '中等支持'
        else:
            conclusion = f"大陆内部贩运占{within_pct:.1f}%，不支持假设"
            support_level = '不支持'
        
        results['结论'] = conclusion
        results['假设支持度'] = support_level
        
        print(f"\n结论: {conclusion}")
        print(f"假设支持度: {support_level}")
        
        self.results['假设3'] = results
        return results
    
    def run_all_tests(self) -> Dict:
        """运行所有假设测试"""
        print("\n" + "="*70)
        print(" "*15 + "全球人口贩运网络假设测试")
        print("="*70)
        
        # 测试假设1
        self.test_hypothesis_1()
        
        # 测试假设2
        self.test_hypothesis_2()
        
        # 测试假设3
        self.test_hypothesis_3()
        
        # 总结
        print("\n" + "="*70)
        print(" "*25 + "测试总结")
        print("="*70)
        
        for i in range(1, 4):
            hyp_key = f'假设{i}'
            if hyp_key in self.results:
                print(f"\n{hyp_key}:")
                print(f"  内容: {self.results[hyp_key]['假设']}")
                print(f"  支持度: {self.results[hyp_key]['假设支持度']}")
                print(f"  结论: {self.results[hyp_key]['结论']}")
        
        return self.results


if __name__ == '__main__':
    print("="*60)
    print("全球人口贩运网络 - 假设测试")
    print("="*60)
    
    # 导入数据
    from data_loader import TraffickingDataLoader
    
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    victim_data = loader.load_victim_data()
    edge_data = loader.load_edge_data()
    
    # 创建测试器并运行所有测试
    tester = HypothesisTester(victim_data, edge_data)
    results = tester.run_all_tests()
    
    print("\n所有假设测试完成！")

