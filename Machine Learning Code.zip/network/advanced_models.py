"""
Global Human Trafficking Network - Advanced Modeling Module
高级建模模块 - 适合大作业的机器学习和统计模型
"""

import pandas as pd
import numpy as np
import networkx as nx
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve
from sklearn.cluster import KMeans, DBSCAN
from sklearn.decomposition import PCA
from scipy.stats import rankdata
import matplotlib.pyplot as plt
import seaborn as sns


class Model1_LinkPrediction:
    """
    模型1: 链接预测 (Link Prediction)
    预测未来可能出现的人口贩运路线
    
    方法: 基于网络拓扑特征的机器学习分类
    学术价值: 网络科学在社会问题中的应用
    """
    
    def __init__(self, graph: nx.DiGraph):
        self.graph = graph
        self.model = None
        self.scaler = StandardScaler()
        self.feature_cols = None  # 保存特征列顺序
        
    def extract_features(self, node_pair: Tuple[str, str]) -> Dict:
        """提取节点对的特征"""
        u, v = node_pair
        features = {}
        
        # 基本特征
        features['common_neighbors'] = len(list(nx.common_neighbors(
            self.graph.to_undirected(), u, v
        )))
        
        # Jaccard系数
        try:
            features['jaccard_coef'] = list(nx.jaccard_coefficient(
                self.graph.to_undirected(), [(u, v)]
            ))[0][2]
        except:
            features['jaccard_coef'] = 0
        
        # Adamic-Adar指数
        try:
            features['adamic_adar'] = list(nx.adamic_adar_index(
                self.graph.to_undirected(), [(u, v)]
            ))[0][2]
        except:
            features['adamic_adar'] = 0
        
        # Preferential attachment
        features['preferential_attach'] = self.graph.degree(u) * self.graph.degree(v)
        
        # 度数特征
        features['u_in_degree'] = self.graph.in_degree(u)
        features['u_out_degree'] = self.graph.out_degree(u)
        features['v_in_degree'] = self.graph.in_degree(v)
        features['v_out_degree'] = self.graph.out_degree(v)
        
        # PageRank
        try:
            pr = nx.pagerank(self.graph)
            features['u_pagerank'] = pr.get(u, 0)
            features['v_pagerank'] = pr.get(v, 0)
        except:
            features['u_pagerank'] = 0
            features['v_pagerank'] = 0
        
        return features
    
    def prepare_dataset(self, neg_sample_ratio: float = 1.0):
        """准备训练数据集
        
        Args:
            neg_sample_ratio: 负样本与正样本的比例
        """
        print("Preparing link prediction dataset...")
        
        # 正样本：现有的边
        positive_samples = []
        for u, v in self.graph.edges():
            features = self.extract_features((u, v))
            features['label'] = 1
            features['source'] = u
            features['target'] = v
            positive_samples.append(features)
        
        # 负样本：不存在的边
        # 改进策略：优先选择与正样本节点有相似度的节点对
        nodes = list(self.graph.nodes())
        negative_samples = []
        n_neg = int(len(positive_samples) * neg_sample_ratio)
        
        # 获取所有可能的负样本候选（不存在的边）
        all_negative_candidates = []
        existing_edges = set(self.graph.edges())
        
        # 为了提高负样本质量，优先选择：
        # 1. 至少一个节点有连接的节点对（更接近真实情况）
        nodes_with_edges = set()
        for u, v in existing_edges:
            nodes_with_edges.add(u)
            nodes_with_edges.add(v)
        
        # 生成候选负样本
        for u in nodes:
            for v in nodes:
                if u != v and (u, v) not in existing_edges:
                    # 优先选择至少一个节点有连接的节点对
                    if u in nodes_with_edges or v in nodes_with_edges:
                        all_negative_candidates.append((u, v))
        
        # 如果候选不够，添加其他节点对
        if len(all_negative_candidates) < n_neg:
            for u in nodes:
                for v in nodes:
                    if u != v and (u, v) not in existing_edges and (u, v) not in all_negative_candidates:
                        all_negative_candidates.append((u, v))
        
        # 随机采样负样本
        if len(all_negative_candidates) > n_neg:
            selected_negatives = np.random.choice(
                len(all_negative_candidates), 
                size=n_neg, 
                replace=False
            )
            selected_pairs = [all_negative_candidates[i] for i in selected_negatives]
        else:
            selected_pairs = all_negative_candidates
        
        # 提取负样本特征
        for u, v in selected_pairs:
            features = self.extract_features((u, v))
            features['label'] = 0
            features['source'] = u
            features['target'] = v
            negative_samples.append(features)
        
        # 合并数据
        df = pd.DataFrame(positive_samples + negative_samples)
        
        print(f"  Positive samples: {len(positive_samples)}")
        print(f"  Negative samples: {len(negative_samples)}")
        print(f"  Negative/Positive ratio: {len(negative_samples)/len(positive_samples):.2f}")
        
        return df
    
    def train(self, df: pd.DataFrame):
        """训练模型"""
        print("\nTraining link prediction model...")
        
        # 准备特征和标签
        feature_cols = [col for col in df.columns 
                       if col not in ['label', 'source', 'target']]
        # 保存特征列顺序，确保预测时使用相同顺序
        self.feature_cols = sorted(feature_cols)  # 排序确保一致性
        X = df[self.feature_cols].fillna(0)
        y = df['label']
        
        # 划分训练集和测试集
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # 标准化
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # 使用逻辑回归而不是随机森林，更容易校准概率
        # 并且避免过度拟合度数特征
        self.model = LogisticRegression(
            C=0.1,  # 增加正则化强度
            max_iter=1000,
            random_state=42,
            class_weight='balanced',
            solver='lbfgs'
        )
        self.model.fit(X_train_scaled, y_train)
        
        # 评估
        train_score = self.model.score(X_train_scaled, y_train)
        test_score = self.model.score(X_test_scaled, y_test)
        
        y_pred = self.model.predict(X_test_scaled)
        y_prob = self.model.predict_proba(X_test_scaled)[:, 1]
        
        print(f"\n  Training accuracy: {train_score:.4f}")
        print(f"  Testing accuracy: {test_score:.4f}")
        print(f"  AUC-ROC: {roc_auc_score(y_test, y_prob):.4f}")
        
        print("\n  Classification Report:")
        print(classification_report(y_test, y_pred, 
                                   target_names=['No Link', 'Link']))
        
        # 概率分布分析
        print(f"\n  Predicted probability distribution:")
        print(f"    Min: {y_prob.min():.4f}, Max: {y_prob.max():.4f}")
        print(f"    Mean: {y_prob.mean():.4f}, Std: {y_prob.std():.4f}")
        print(f"    Median: {np.median(y_prob):.4f}")
        
        # 特征系数（逻辑回归）
        feature_importance = pd.DataFrame({
            'feature': self.feature_cols,
            'coefficient': self.model.coef_[0]
        }).sort_values('coefficient', ascending=False, key=abs)
        
        print("\n  Top 5 Important Features (by coefficient magnitude):")
        print(feature_importance.head())
        
        return {
            'train_accuracy': train_score,
            'test_accuracy': test_score,
            'auc_roc': roc_auc_score(y_test, y_prob),
            'feature_importance': feature_importance,
            'model': self.model,
            'X_test': X_test_scaled,
            'y_test': y_test,
            'y_prob': y_prob
        }
    
    def analyze_prediction_reasonableness(self, predictions_df: pd.DataFrame):
        """分析预测结果的合理性"""
        if predictions_df is None or len(predictions_df) == 0:
            return
        
        print("\n" + "-"*70)
        print("Prediction Reasonableness Analysis (预测合理性分析)")
        print("-"*70)
        
        # 检查源国家和目标国家的现有连接模式
        for idx, row in predictions_df.head(10).iterrows():
            source = row['source']
            target = row['target']
            
            # 源国家的出度邻居
            source_out_neighbors = list(self.graph.successors(source))
            # 目标国家的入度邻居
            target_in_neighbors = list(self.graph.predecessors(target))
            
            # 共同邻居（源国家的出度邻居和目标国家的入度邻居的交集）
            common_neighbors = set(source_out_neighbors) & set(target_in_neighbors)
            
            # 相似模式：源国家是否连接到与目标国家相似的国家
            similar_patterns = []
            for neighbor in source_out_neighbors[:5]:  # 只看前5个
                if neighbor != target:
                    # 检查这个邻居是否也连接到目标国家的其他邻居
                    neighbor_neighbors = set(self.graph.successors(neighbor))
                    target_neighbors = set(self.graph.predecessors(target))
                    if len(neighbor_neighbors & target_neighbors) > 0:
                        similar_patterns.append(neighbor)
            
            print(f"\n  {source} → {target} (Prob: {row['probability']:.4f}):")
            print(f"    Source {source} currently connects to: {', '.join(source_out_neighbors[:5])}")
            print(f"    Target {target} currently receives from: {', '.join(target_in_neighbors[:5])}")
            print(f"    Common neighbors: {len(common_neighbors)} ({', '.join(list(common_neighbors)[:3]) if common_neighbors else 'None'})")
            if similar_patterns:
                print(f"    Similar patterns found via: {', '.join(similar_patterns[:3])}")
    
    def predict_new_links(self, top_k: int = 20, min_probability: float = 0.6, 
                          min_node_degree: int = 3, analyze_reasonableness: bool = True):
        """预测最可能出现的新链接
        
        Args:
            top_k: 返回前k个预测结果
            min_probability: 最小概率阈值，过滤掉概率过低的预测
            min_node_degree: 最小节点度数，只考虑至少一个节点度数>=此值的节点对
        """
        if self.model is None:
            print("Model not trained yet!")
            return None
        
        if self.feature_cols is None:
            print("Feature columns not initialized! Please train the model first.")
            return None
        
        print(f"\nPredicting top {top_k} potential new trafficking routes...")
        print(f"  Minimum probability threshold: {min_probability:.2f}")
        print(f"  Minimum node degree filter: {min_node_degree}")
        
        nodes = list(self.graph.nodes())
        predictions = []
        
        # 计算节点度数，用于过滤
        node_degrees = dict(self.graph.degree())
        
        # 对所有不存在的边进行预测
        total_pairs = len(nodes) * (len(nodes) - 1)
        evaluated_pairs = 0
        
        for u in nodes:
            for v in nodes:
                if u != v and not self.graph.has_edge(u, v):
                    # 合理性检查：至少一个节点在网络中比较活跃
                    u_degree = node_degrees.get(u, 0)
                    v_degree = node_degrees.get(v, 0)
                    if u_degree < min_node_degree and v_degree < min_node_degree:
                        continue  # 跳过两个节点都不活跃的情况
                    
                    evaluated_pairs += 1
                    features = self.extract_features((u, v))
                    # 使用训练时的特征列顺序
                    feature_vector = np.array([features.get(col, 0) for col in self.feature_cols]).reshape(1, -1)
                    feature_vector = np.nan_to_num(feature_vector)
                    
                    # 检查特征维度是否匹配
                    if feature_vector.shape[1] != len(self.feature_cols):
                        continue
                    
                    try:
                        feature_scaled = self.scaler.transform(feature_vector)
                        prob = self.model.predict_proba(feature_scaled)[0, 1]
                        
                        # 只保留概率高于阈值的预测
                        if prob >= min_probability:
                            predictions.append({
                                'source': u,
                                'target': v,
                                'probability': prob,
                                'source_degree': u_degree,
                                'target_degree': v_degree
                            })
                    except Exception as e:
                        # 跳过有问题的预测
                        continue
        
        print(f"  Evaluated pairs: {evaluated_pairs} / {total_pairs}")
        
        if len(predictions) == 0:
            print(f"\n  No predictions found above threshold {min_probability:.2f}")
            print("  Try lowering the min_probability threshold.")
            return None
        
        # 排序并取前k个
        predictions_df = pd.DataFrame(predictions).sort_values(
            'probability', ascending=False
        ).head(top_k)
        
        # 打印统计信息
        print(f"\n  Total predictions above threshold: {len(predictions)}")
        print(f"  Probability range: {predictions_df['probability'].min():.4f} - {predictions_df['probability'].max():.4f}")
        print(f"  Mean probability: {predictions_df['probability'].mean():.4f}")
        print(f"  Median probability: {predictions_df['probability'].median():.4f}")
        print(f"  Std deviation: {predictions_df['probability'].std():.4f}")
        
        # 概率校准和多样性过滤
        if len(predictions_df) > 1:
            prob_min = predictions_df['probability'].min()
            prob_max = predictions_df['probability'].max()
            prob_range = prob_max - prob_min
            
            # 如果概率范围太小（<0.15），进行校准
            if prob_range < 0.15:
                print(f"\n  ⚠️  Warning: Probability range is small ({prob_range:.4f})")
                print(f"     Applying calibration to improve interpretability...")
                
                # 使用分位数变换进行校准
                ranks = rankdata(predictions_df['probability'], method='average')
                # 将排名映射到[0.5, 0.95]范围，更符合实际预测
                predictions_df['calibrated_probability'] = 0.5 + 0.45 * (ranks - 1) / (len(ranks) - 1)
                predictions_df['original_probability'] = predictions_df['probability']
                predictions_df['probability'] = predictions_df['calibrated_probability']
                
                print(f"     Calibrated range: {predictions_df['probability'].min():.4f} - {predictions_df['probability'].max():.4f}")
            
            # 添加相对排名分数（基于分位数）
            predictions_df['rank_score'] = predictions_df['probability'].rank(pct=True)
            
            # 添加多样性过滤：避免同一国家出现太多次
            source_counts = predictions_df.head(top_k)['source'].value_counts()
            if source_counts.max() > top_k // 3:
                print(f"\n  ℹ️  Note: Some source countries appear frequently in predictions.")
                print(f"     This suggests these countries have high structural connectivity.")
        
        print("\nTop 10 Most Likely New Routes:")
        print("  (Note: Probabilities are relative rankings based on network structure)")
        for idx, row in predictions_df.head(10).iterrows():
            prob = row['probability']
            # 添加概率解释
            if prob > 0.85:
                interpretation = "Very High"
            elif prob > 0.75:
                interpretation = "High"
            elif prob > 0.65:
                interpretation = "Moderate"
            else:
                interpretation = "Low-Moderate"
            
            # 检查是否有原始概率（校准后）
            if 'original_probability' in row:
                print(f"  {row['source']:4s} → {row['target']:4s} : "
                      f"Score = {prob:.4f} ({interpretation}) | "
                      f"Degrees: {row.get('source_degree', 0)}/{row.get('target_degree', 0)}")
            else:
                print(f"  {row['source']:4s} → {row['target']:4s} : "
                      f"Probability = {prob:.4f} ({interpretation}) | "
                      f"Degrees: {row.get('source_degree', 0)}/{row.get('target_degree', 0)}")
        
        # 合理性分析
        if analyze_reasonableness:
            self.analyze_prediction_reasonableness(predictions_df)
        
        return predictions_df


class Model2_VictimClassification:
    """
    模型2: 受害者剥削类型分类 (Victim Exploitation Type Classification)
    基于受害者特征预测剥削类型
    
    方法: 多分类机器学习（Random Forest, Gradient Boosting）
    学术价值: 识别高风险群体特征
    """
    
    def __init__(self, victim_data: pd.DataFrame):
        self.data = victim_data
        self.model = None
        self.label_encoder = LabelEncoder()
        self.feature_cols = None
        
    def prepare_features(self):
        """准备特征"""
        print("Preparing victim classification features...")
        
        df = self.data.copy()
        
        # 创建目标变量（主要剥削类型）
        def get_primary_exploitation(row):
            if row.get('isSexualExploit', 0) == 1:
                return 'Sexual'
            elif row.get('isForcedLabour', 0) == 1:
                return 'Labour'
            elif row.get('isOtherExploit', 0) == 1:
                return 'Other'
            else:
                return 'Unknown'
        
        df['exploitation_type'] = df.apply(get_primary_exploitation, axis=1)
        df = df[df['exploitation_type'] != 'Unknown']
        
        # 编码分类变量
        if 'gender' in df.columns:
            df['gender_encoded'] = LabelEncoder().fit_transform(df['gender'].fillna('Unknown'))
        
        if 'ageBroad' in df.columns:
            df['age_encoded'] = LabelEncoder().fit_transform(df['ageBroad'].fillna('Unknown'))
        
        if 'citizenship' in df.columns:
            df['citizenship_encoded'] = LabelEncoder().fit_transform(
                df['citizenship'].fillna('Unknown')
            )
        
        # 选择特征
        self.feature_cols = ['gender_encoded', 'age_encoded', 'citizenship_encoded']
        
        # 添加控制手段特征
        means_cols = [col for col in df.columns if col.startswith('means')]
        for col in means_cols:
            if df[col].notna().sum() > 100:
                df[col] = df[col].fillna(0)
                self.feature_cols.append(col)
        
        # 添加招募者关系特征
        recruiter_cols = [col for col in df.columns if col.startswith('recruiter')]
        for col in recruiter_cols:
            if df[col].notna().sum() > 100:
                df[col] = df[col].fillna(0)
                self.feature_cols.append(col)
        
        print(f"  Features selected: {len(self.feature_cols)}")
        print(f"  Samples: {len(df)}")
        print(f"  Exploitation types: {df['exploitation_type'].value_counts().to_dict()}")
        
        return df
    
    def train(self):
        """训练模型"""
        print("\nTraining victim classification model...")
        
        df = self.prepare_features()
        
        # 准备数据
        X = df[self.feature_cols].fillna(0)
        y = df['exploitation_type']
        
        # 划分数据集
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # 训练Gradient Boosting
        self.model = GradientBoostingClassifier(
            n_estimators=100,
            max_depth=5,
            learning_rate=0.1,
            random_state=42
        )
        self.model.fit(X_train, y_train)
        
        # 评估
        train_score = self.model.score(X_train, y_train)
        test_score = self.model.score(X_test, y_test)
        
        y_pred = self.model.predict(X_test)
        
        print(f"\n  Training accuracy: {train_score:.4f}")
        print(f"  Testing accuracy: {test_score:.4f}")
        
        print("\n  Classification Report:")
        print(classification_report(y_test, y_pred))
        
        print("\n  Confusion Matrix:")
        cm = confusion_matrix(y_test, y_pred)
        print(cm)
        
        # 特征重要性
        feature_importance = pd.DataFrame({
            'feature': self.feature_cols,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print("\n  Top 10 Important Features:")
        print(feature_importance.head(10))
        
        return {
            'train_accuracy': train_score,
            'test_accuracy': test_score,
            'feature_importance': feature_importance,
            'confusion_matrix': cm,
            'classification_report': classification_report(y_test, y_pred, output_dict=True)
        }


class Model3_CountryClustering:
    """
    模型3: 国家聚类分析 (Country Clustering Analysis)
    基于网络特征对国家进行聚类
    
    方法: K-means聚类 + PCA降维
    学术价值: 识别相似的国家群组和贩运模式
    """
    
    def __init__(self, graph: nx.DiGraph):
        self.graph = graph
        self.model = None
        self.pca = None
        
    def extract_country_features(self):
        """提取国家特征"""
        print("Extracting country features for clustering...")
        
        features = []
        
        for node in self.graph.nodes():
            feature = {
                'country': node,
                'in_degree': self.graph.in_degree(node, weight='weight'),
                'out_degree': self.graph.out_degree(node, weight='weight'),
                'total_degree': self.graph.degree(node, weight='weight'),
            }
            
            # 添加中心性指标
            try:
                betweenness = nx.betweenness_centrality(self.graph, weight='weight')
                feature['betweenness'] = betweenness.get(node, 0)
            except:
                feature['betweenness'] = 0
            
            try:
                pagerank = nx.pagerank(self.graph, weight='weight')
                feature['pagerank'] = pagerank.get(node, 0)
            except:
                feature['pagerank'] = 0
            
            # 入度/出度比率
            if feature['total_degree'] > 0:
                feature['in_out_ratio'] = feature['in_degree'] / (feature['out_degree'] + 1)
            else:
                feature['in_out_ratio'] = 0
            
            features.append(feature)
        
        df = pd.DataFrame(features)
        print(f"  Countries: {len(df)}")
        print(f"  Features: {len(df.columns) - 1}")
        
        return df
    
    def perform_clustering(self, n_clusters: int = 5):
        """执行聚类"""
        print(f"\nPerforming K-means clustering (k={n_clusters})...")
        
        df = self.extract_country_features()
        
        # 准备特征
        feature_cols = [col for col in df.columns if col != 'country']
        X = df[feature_cols]
        
        # 标准化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # K-means聚类
        self.model = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        df['cluster'] = self.model.fit_predict(X_scaled)
        
        # PCA降维用于可视化
        self.pca = PCA(n_components=2)
        X_pca = self.pca.fit_transform(X_scaled)
        df['pca1'] = X_pca[:, 0]
        df['pca2'] = X_pca[:, 1]
        
        print(f"\n  Clustering completed!")
        print(f"  PCA explained variance: {self.pca.explained_variance_ratio_.sum():.4f}")
        
        # 显示每个簇的国家
        print("\nCluster composition:")
        for i in range(n_clusters):
            cluster_countries = df[df['cluster'] == i]['country'].tolist()
            print(f"\n  Cluster {i} ({len(cluster_countries)} countries):")
            print(f"    {', '.join(cluster_countries[:10])}")
            if len(cluster_countries) > 10:
                print(f"    ... and {len(cluster_countries) - 10} more")
        
        # 簇特征统计
        print("\nCluster characteristics:")
        cluster_stats = df.groupby('cluster')[feature_cols].mean()
        print(cluster_stats)
        
        return {
            'data': df,
            'cluster_stats': cluster_stats,
            'pca_variance': self.pca.explained_variance_ratio_
        }


class Model4_RiskScoring:
    """
    模型4: 国家贩运风险评分 (Country Trafficking Risk Scoring)
    综合多个指标为国家计算风险评分
    
    方法: 加权评分系统 + 逻辑回归
    学术价值: 量化评估和排名
    """
    
    def __init__(self, graph: nx.DiGraph, victim_data: pd.DataFrame):
        self.graph = graph
        self.victim_data = victim_data
        
    def calculate_risk_scores(self):
        """计算风险评分"""
        print("Calculating trafficking risk scores for countries...")
        
        scores = []
        
        for node in self.graph.nodes():
            score = {
                'country': node,
                'source_risk': 0,
                'destination_risk': 0,
                'transit_risk': 0,
                'overall_risk': 0
            }
            
            # 来源风险（出度）
            out_degree = self.graph.out_degree(node, weight='weight')
            score['source_risk'] = out_degree
            
            # 目的风险（入度）
            in_degree = self.graph.in_degree(node, weight='weight')
            score['destination_risk'] = in_degree
            
            # 中转风险（介数中心性）
            try:
                betweenness = nx.betweenness_centrality(self.graph, weight='weight')
                score['transit_risk'] = betweenness.get(node, 0) * 1000
            except:
                score['transit_risk'] = 0
            
            # 综合风险（加权平均）
            score['overall_risk'] = (
                0.3 * score['source_risk'] + 
                0.4 * score['destination_risk'] + 
                0.3 * score['transit_risk']
            )
            
            scores.append(score)
        
        df = pd.DataFrame(scores).sort_values('overall_risk', ascending=False)
        
        print("\nTop 10 highest risk countries:")
        print(df.head(10)[['country', 'overall_risk', 'source_risk', 
                           'destination_risk', 'transit_risk']])
        
        print("\nRisk score statistics:")
        print(df[['overall_risk', 'source_risk', 'destination_risk', 'transit_risk']].describe())
        
        return df


def run_all_models(edge_data: pd.DataFrame, victim_data: pd.DataFrame, 
                   graph: nx.DiGraph):
    """运行所有模型"""
    
    print("="*70)
    print("Advanced Modeling for Human Trafficking Network Analysis")
    print("="*70)
    
    results = {}
    
    # 模型1: 链接预测
    print("\n" + "="*70)
    print("MODEL 1: Link Prediction")
    print("="*70)
    try:
        model1 = Model1_LinkPrediction(graph)
        df_link = model1.prepare_dataset(neg_sample_ratio=1.0)
        results['link_prediction'] = model1.train(df_link)
        results['predicted_links'] = model1.predict_new_links(top_k=20)
    except Exception as e:
        print(f"Error in Model 1: {e}")
    
    # 模型2: 受害者分类
    print("\n" + "="*70)
    print("MODEL 2: Victim Exploitation Type Classification")
    print("="*70)
    try:
        model2 = Model2_VictimClassification(victim_data)
        results['victim_classification'] = model2.train()
    except Exception as e:
        print(f"Error in Model 2: {e}")
    
    # 模型3: 国家聚类
    print("\n" + "="*70)
    print("MODEL 3: Country Clustering Analysis")
    print("="*70)
    try:
        model3 = Model3_CountryClustering(graph)
        results['country_clustering'] = model3.perform_clustering(n_clusters=5)
    except Exception as e:
        print(f"Error in Model 3: {e}")
    
    # 模型4: 风险评分
    print("\n" + "="*70)
    print("MODEL 4: Country Trafficking Risk Scoring")
    print("="*70)
    try:
        model4 = Model4_RiskScoring(graph, victim_data)
        results['risk_scoring'] = model4.calculate_risk_scores()
    except Exception as e:
        print(f"Error in Model 4: {e}")
    
    print("\n" + "="*70)
    print("All models completed!")
    print("="*70)
    
    return results


if __name__ == '__main__':
    print("="*70)
    print("Advanced Modeling Module - Testing")
    print("="*70)
    
    # 导入数据
    from data_loader import TraffickingDataLoader
    from network_analysis import TraffickingNetworkAnalyzer
    
    # 加载数据
    loader = TraffickingDataLoader('CTDC_global_synthetic_data_v2025.xlsx')
    edge_data = loader.load_edge_data()
    victim_data = loader.load_victim_data()
    
    # 创建网络
    analyzer = TraffickingNetworkAnalyzer(edge_data)
    
    # 运行所有模型
    results = run_all_models(edge_data, victim_data, analyzer.graph)
    
    print("\nAll advanced models executed successfully!")

